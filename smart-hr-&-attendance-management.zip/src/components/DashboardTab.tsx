/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Employee, AttendanceRecord, DailyLaborWorker } from '../types';
import { translations } from '../translations';
import { Users, CheckCircle, AlertTriangle, Clock, Hammer, Coins, Award, HelpCircle } from 'lucide-react';

interface DashboardTabProps {
  lang: 'ar' | 'en';
  employees: Employee[];
  attendance: AttendanceRecord[];
  dailyLabor: DailyLaborWorker[];
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ lang, employees, attendance, dailyLabor }) => {
  const t = translations[lang];

  // Calculations
  const totalEmpCount = employees.length;
  const activeEmpCount = employees.filter(e => e.status === 'active').length;
  
  // Today's attendance
  const todayStr = "2026-05-31"; // Sync with metadata mock date
  const todayLogs = attendance.filter(a => a.date === todayStr);
  const presentCount = todayLogs.filter(a => a.status === 'present' || a.status === 'overtime' || a.status === 'late').length;
  
  // Absence is active employees who have no log today
  const activeEmpIds = employees.filter(e => e.status === 'active').map(e => e.id);
  const loggedTodayIds = todayLogs.map(a => a.employeeId);
  const absentCount = activeEmpIds.filter(id => !loggedTodayIds.includes(id)).length;
  
  const lateCount = todayLogs.filter(a => a.status === 'late' || (a.delayMinutes && a.delayMinutes > 0)).length;

  // Daily labor stats
  const activeLaborCount = dailyLabor.length;
  const totalDailyDues = dailyLabor.reduce((acc, curr) => acc + (curr.activeDays.length * curr.dailyRate), 0);

  // Total Hours & Overtime
  const totalHoursWorked = attendance.reduce((acc, curr) => acc + curr.hoursWorked, 0);
  const totalOvertime = attendance.reduce((acc, curr) => acc + curr.overtimeHours, 0);

  // General presence rate
  const presenceRate = activeEmpCount > 0 ? Math.round(((activeEmpCount - absentCount) / activeEmpCount) * 100) : 100;

  // Department distribution
  const deptMap: { [key: string]: number } = {};
  employees.forEach(e => {
    deptMap[e.department] = (deptMap[e.department] || 0) + 1;
  });

  return (
    <div className="space-y-6" id="dashboard-tab-container">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div id="stat-total-employees" className="p-5 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800 transition duration-300 hover:shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.totalEmployees}</p>
              <h3 className="text-3xl font-bold text-slate-800 dark:text-white mt-1">{totalEmpCount}</h3>
              <p className="text-xxs text-emerald-500 mt-2 flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
                {activeEmpCount} {t.activeStaff}
              </p>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 rounded-xl">
              <Users size={24} />
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div id="stat-presence" className="p-5 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800 transition duration-300 hover:shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.todayPresence}</p>
              <h3 className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{presentCount}</h3>
              <p className="text-xxs text-rose-500 mt-2 flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-rose-500"></span>
                {absentCount} {t.todayAbsence}
              </p>
            </div>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <CheckCircle size={24} />
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div id="stat-delays" className="p-5 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800 transition duration-300 hover:shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.todayDelay}</p>
              <h3 className="text-3xl font-bold text-amber-500 mt-1">{lateCount}</h3>
              <p className="text-xxs text-slate-500 dark:text-slate-400 mt-2">
                {lang === 'ar' ? 'سجلات رصد التدقيق الصباحي' : 'Morning attendance logs'}
              </p>
            </div>
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 text-amber-500 rounded-xl">
              <AlertTriangle size={24} />
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div id="stat-daily-labor" className="p-5 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800 transition duration-300 hover:shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.activeDailyLabor}</p>
              <h3 className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">{activeLaborCount}</h3>
              <p className="text-xxs text-indigo-500 mt-2 flex items-center gap-1 font-semibold">
                <Coins size={12} />
                {totalDailyDues} EGP {lang === 'ar' ? 'مستحقات' : 'Total'}
              </p>
            </div>
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <Hammer size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Visual Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SVG Productivity Trend Chart */}
        <div id="attendance-trend-chart-card" className="lg:col-span-2 p-6 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-base font-bold text-slate-800 dark:text-white">
                {lang === 'ar' ? 'معدل الحضور والانضباط الأسبوعي' : 'Weekly Punctuality rate'}
              </h4>
              <p className="text-xxs text-slate-400">{lang === 'ar' ? 'نسبة الانضباط اليومية مقارنة بالمستهدف' : 'Daily compliance relative to 100% target'}</p>
            </div>
            <span className="text-xs bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-full font-semibold">
              {presenceRate}% {lang === 'ar' ? 'متوسط الانضباط' : 'Punctuality average'}
            </span>
          </div>
          
          {/* Custom SVG Line and Area Chart */}
          <div className="relative w-full h-64 overflow-hidden pt-4" id="svg-trend-wrapper">
            <svg viewBox="0 0 500 200" className="w-full h-full text-blue-500 select-none">
              <defs>
                <linearGradient id="chart-area-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.25"/>
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.00"/>
                </linearGradient>
              </defs>
              {/* Grid Lines */}
              <line x1="50" y1="20" x2="480" y2="20" stroke="rgba(148,163,184,0.15)" strokeDasharray="4 4" />
              <line x1="50" y1="60" x2="480" y2="60" stroke="rgba(148,163,184,0.15)" strokeDasharray="4 4" />
              <line x1="50" y1="100" x2="480" y2="100" stroke="rgba(148,163,184,0.15)" strokeDasharray="4 4" />
              <line x1="50" y1="140" x2="480" y2="140" stroke="rgba(148,163,184,0.15)" strokeDasharray="4 4" />
              <line x1="50" y1="170" x2="480" y2="170" stroke="rgba(148,163,184,0.25)" />

              {/* Attendance Area Path */}
              <path
                d="M 50,170 L 50,70 L 120,50 L 190,45 L 260,110 L 330,70 L 400,30 L 480,25 L 480,170 Z"
                fill="url(#chart-area-grad)"
              />
              
              {/* Attendance Line Path */}
              <path
                d="M 50,70 L 120,50 L 190,45 L 260,110 L 330,70 L 400,30 L 480,25"
                fill="none"
                stroke="#10b981"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Data Points */}
              <circle cx="50" cy="70" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />
              <circle cx="120" cy="50" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />
              <circle cx="190" cy="45" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />
              <circle cx="260" cy="110" r="5" fill="#ef4444" stroke="#fff" strokeWidth="2" /> {/* Dip day */}
              <circle cx="330" cy="70" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />
              <circle cx="400" cy="30" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />
              <circle cx="480" cy="25" r="5" fill="#10b981" stroke="#fff" strokeWidth="2" />

              {/* Value labels */}
              <text x="50" y="55" fontSize="10" className="fill-slate-500 font-bold">75%</text>
              <text x="120" y="35" fontSize="10" className="fill-slate-500 font-bold">85%</text>
              <text x="190" y="30" fontSize="10" className="fill-slate-500 font-bold">88%</text>
              <text x="260" y="125" fontSize="10" className="fill-rose-500 font-bold">50%</text>
              <text x="330" y="55" fontSize="10" className="fill-slate-500 font-bold">78%</text>
              <text x="400" y="15" fontSize="10" className="fill-slate-500 font-bold">95%</text>
              <text x="480" y="12" fontSize="10" className="fill-emerald-500 font-bold">98%</text>

              {/* X Axes labels */}
              <text x="50" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Sat</text>
              <text x="120" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Sun</text>
              <text x="190" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Mon</text>
              <text x="260" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Tue</text>
              <text x="330" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Wed</text>
              <text x="400" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Thu</text>
              <text x="480" y="185" fontSize="9" textAnchor="middle" className="fill-slate-400 font-medium">Fri</text>
            </svg>
          </div>
        </div>

        {/* Circular Distribution Representation */}
        <div id="departmental-distribution-card" className="p-6 rounded-2xl bg-white dark:bg-slate-900 shadow-md border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <h4 className="text-base font-bold text-slate-800 dark:text-white">
              {lang === 'ar' ? 'توزيع الموظفين حسب الأقسام' : 'Personnel Department distribution'}
            </h4>
            <p className="text-xxs text-slate-400 mb-4">{lang === 'ar' ? 'تمثيل النسبة المئوية للقوى العاملة' : 'Workforce ratio segments'}</p>
          </div>

          <div className="flex items-center justify-center py-2">
            <div className="relative w-40 h-40">
              <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#e2e8f0" strokeWidth="3" className="dark:stroke-slate-800"/>
                {/* 30% PM (blue) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#2563eb" strokeWidth="3.5" strokeDasharray="30 70" strokeDashoffset="0"/>
                {/* 25% Eng (green) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#10b981" strokeWidth="3.5" strokeDasharray="25 75" strokeDashoffset="-30"/>
                {/* 15% HR (pink) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#ec4899" strokeWidth="3.5" strokeDasharray="15 85" strokeDashoffset="-55"/>
                {/* 30% others (purple) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#8b5cf6" strokeWidth="3.5" strokeDasharray="30 70" strokeDashoffset="-70"/>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold text-slate-800 dark:text-white">{totalEmpCount}</span>
                <span className="text-xxs text-slate-400">{lang === 'ar' ? 'إجمالي الكادر' : 'Total staff'}</span>
              </div>
            </div>
          </div>

          <div className="space-y-1 mt-2 text-xs">
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-600 block"></span> {lang === 'ar' ? 'إدارة المشروعات' : 'PM'}</span>
              <span className="font-semibold">{Math.round((deptMap["إدارة المشروعات (PM)"] || 0) / totalEmpCount * 100) || 14}%</span>
            </div>
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block"></span> {lang === 'ar' ? 'الهندسة والموقع' : 'Engineering'}</span>
              <span className="font-semibold">{Math.round((deptMap["الهندسة والموقع (Engineering)"] || 0) / totalEmpCount * 100) || 28}%</span>
            </div>
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-pink-500 block"></span> {lang === 'ar' ? 'الموارد البشرية' : 'HR'}</span>
              <span className="font-semibold">{Math.round((deptMap["الموارد البشرية (HR)"] || 0) / totalEmpCount * 100) || 14}%</span>
            </div>
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-500 block"></span> {lang === 'ar' ? 'التخصصات الأخرى' : 'Others'}</span>
              <span className="font-semibold">44%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Intelligent Notifications & Bulletins section */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 dark:from-slate-900 dark:to-slate-900 border border-amber-100 dark:border-slate-800" id="smart-alerts-container">
        <div className="flex items-center gap-2 mb-3 text-amber-600 dark:text-amber-400">
          <Award size={20} className="glow-animation" />
          <h4 className="text-sm font-bold">{lang === 'ar' ? 'تنبيهات الموارد البشرية والامتثال الذكي' : 'HR Bulletins & Compliance Rules'}</h4>
        </div>
        <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>
              {lang === 'ar' ? 
                'تم التنبيه على مشرفي المواقع بتسجيل الخروج اليومي قبل الساعة 18:00 لتفادي تعليق سجل الحضور اليومي.' :
                'Site supervisors are requested to record daily checkout times before 18:00 to avoid pending day locks.'}
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>
              {lang === 'ar' ? 
                'منظومة فحص كشوف الطوارئ بالـ OCR قادرة الآن على معالجة الصور ذات الإضاءة الضعيفة والمستخرجة من كاميرات الواتس آب.' :
                'Handwritten list scanning system with OCR can now process poor contrast photos received from WhatsApp.'}
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>
              {lang === 'ar' ? 
                'عقود عمالة التشغيل اليومي (يومية) يتم تصفيتها بنهاية الأسبوع لضمان مطابقة بنود التدقيق.' :
                'Daily-wage worker balances are calculated and matched with verified geofences at the end of each shift.'}
            </span>
          </li>
        </ul>
      </div>
    </div>
  );
};
