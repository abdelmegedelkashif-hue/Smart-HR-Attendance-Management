/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Employee, GPSSite, AttendanceRecord } from '../types';
import { INITIAL_SITES, calculateDistance } from '../initialData';
import { translations } from '../translations';
import { MapPin, Camera, Check, ShieldAlert, Navigation, RefreshCw, X, User } from 'lucide-react';

interface GpsMobileTabProps {
  lang: 'ar' | 'en';
  employees: Employee[];
  attendance: AttendanceRecord[];
  setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
}

export const GpsMobileTab: React.FC<GpsMobileTabProps> = ({ lang, employees, attendance, setAttendance }) => {
  const t = translations[lang];

  // States
  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || '');
  const [targetSiteId, setTargetSiteId] = useState(INITIAL_SITES[0].id);

  // Simulation coordinate selections
  // inside vs outside
  const [coordType, setCoordType] = useState<'inside' | 'outside'>('inside');
  const [customLat, setCustomLat] = useState<number>(30.04015); // Cairo HQ coords
  const [customLng, setCustomLng] = useState<number>(31.23355);

  // Selfie capture simulation
  const [selfieSrc, setSelfieSrc] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // References for camera iframe support
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const selectedEmployeeInstance = employees.find(e => e.id === selectedEmpId);
  const selectedSiteInstance = INITIAL_SITES.find(s => s.id === targetSiteId) || INITIAL_SITES[0];

  // Adjust coordinates based on geofence type selected
  const handleCoordTypeChange = (type: 'inside' | 'outside') => {
    setCoordType(type);
    if (type === 'inside') {
      // Situate within 15 meters of target site
      setCustomLat(selectedSiteInstance.lat + 0.0001);
      setCustomLng(selectedSiteInstance.lng + 0.0001);
    } else {
      // Situate 1.8 KM away
      setCustomLat(selectedSiteInstance.lat + 0.015);
      setCustomLng(selectedSiteInstance.lng + 0.015);
    }
    setStatusMsg(null);
  };

  // Distance computation
  const currentDistanceM = Math.round(
    calculateDistance(customLat, customLng, selectedSiteInstance.lat, selectedSiteInstance.lng)
  );
  const isCompliantGeofenced = currentDistanceM <= selectedSiteInstance.radiusM;

  // Camera capture integration
  const startCamera = async () => {
    setIsCameraActive(true);
    setStatusMsg(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn("Camera frame capture denied or unavailable in iframe. Falling back to immersive visual portrait simulation.");
    }
  };

  const captureSnapshot = () => {
    if (videoRef.current) {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 300;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, 300, 300);
          setSelfieSrc(canvas.toDataURL('image/jpeg'));
        }
        // stop camera tracks
        const stream = videoRef.current.srcObject as MediaStream;
        stream?.getTracks().forEach(track => track.stop());
      } catch (err) {
        setSelfieSrc("https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=128&q=80");
      }
    } else {
      // Simulative default high contrast selfie picture
      setSelfieSrc("https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80");
    }
    setIsCameraActive(false);
  };

  // Commit geofenced checkpoint
  const handleGPSCheckIn = () => {
    if (!selectedEmpId) return;
    if (!isCompliantGeofenced) {
      setStatusMsg({
        type: 'error',
        text: lang === 'ar' ? 
          `فشل التحقق: أنت متواجد على مسافة ${currentDistanceM}م خارج الحدود الجغرافية المسموح بها لموقع ${selectedSiteInstance.name.split('-')[0]}!` :
          `Denied: Staged checkpoint is ${currentDistanceM}m outside authorized radius boundaries!`
      });
      return;
    }

    // Capture success
    const todayStr = "2026-05-31"; // today lock
    const hhMm = new Date().toTimeString().split(' ')[0].substring(0, 5); //HH:mm

    // Ensure we do not log duplicate for same date
    const hasTodayLog = attendance.find(a => a.employeeId === selectedEmpId && a.date === todayStr);
    if (hasTodayLog) {
      setStatusMsg({
        type: 'error',
        text: lang === 'ar' ? "لقد قمت بتوثيق حضورك لهذا اليوم مسبقاً!" : "Daily logs already registered."
      });
      return;
    }

    const newLog: AttendanceRecord = {
      id: `GPS-${Date.now()}`,
      employeeId: selectedEmpId,
      employeeName: selectedEmployeeInstance?.name || 'Worker',
      date: todayStr,
      checkIn: "08:00", // standard 24h format
      checkOut: hhMm,
      status: 'present',
      hoursWorked: 8.0,
      overtimeHours: 0.0,
      delayMinutes: 0,
      earlyLeaveMinutes: 0,
      method: 'gps',
      gpsLocation: {
        lat: customLat,
        lng: customLng,
        siteName: selectedSiteInstance.name,
        distanceM: currentDistanceM
      },
      selfieUrl: selfieSrc || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=128&q=80"
    };

    setAttendance([newLog, ...attendance]);
    setStatusMsg({
      type: 'success',
      text: t.checkInSuccess
    });
    setSelfieSrc(null);
  };

  return (
    <div className="space-y-6" id="gps-geofence-tab">
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-sm grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Mockup Mobile Screen wrapper (Left/Self) */}
        <div className="flex flex-col items-center justify-center">
          <div className="w-80 bg-slate-950 text-white rounded-[40px] border-[8px] border-slate-800 p-6 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[540px]">
            {/* Speaker & notch */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-b-2xl z-20 flex items-center justify-center text-[8px] text-emerald-500 font-mono">
              ● GPS ACTIVE
            </div>

            {/* Simulated app header */}
            <div className="pt-4 text-center border-b border-slate-800 pb-3 mt-2">
              <h5 className="text-[11px] font-bold text-slate-300">Smart HRMS Field Companion</h5>
              <div className="text-[8px] text-slate-500 font-mono mt-0.5">Cairo Geolocation Hub v4</div>
            </div>

            {/* Simulated App Body */}
            <div className="flex-1 py-4 space-y-4 text-xs">
              
              {/* Select Mobile Employee login mock */}
              <div>
                <label className="block text-[10px] text-slate-400 mb-1 font-bold">{lang === 'ar' ? 'حدد الهوية لتسجيل الدخول الموقعي:' : 'Login Employee Identity:'}</label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg py-1 px-2 text-[10px] text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                  ))}
                </select>
              </div>

              {/* Geo Check Match Details */}
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-[10px] text-slate-400 pb-1.5 border-b border-slate-800">
                  <span>{lang === 'ar' ? 'مشروع التغطية الجغرافية' : 'Geofence project target'}</span>
                  <span className="font-bold text-indigo-400">{selectedSiteInstance.name.split('-')[0]}</span>
                </div>

                <div className="flex justify-between font-mono text-[10px]">
                  <span className="text-slate-500">RADIUS LIMIT:</span>
                  <span className="text-slate-300">{selectedSiteInstance.radiusM} meters</span>
                </div>
                <div className="flex justify-between font-mono text-[10px]">
                  <span className="text-slate-500">COMPUTED RANGE:</span>
                  <span className={`font-bold ${isCompliantGeofenced ? 'text-emerald-500' : 'text-rose-500'}`}>{currentDistanceM} meters</span>
                </div>

                {/* Compliance Badge */}
                <div className={`mt-2 p-2 rounded-lg text-[9px] font-bold flex items-center gap-1.5 ${
                  isCompliantGeofenced ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/30' : 'bg-rose-950/40 text-rose-400 border border-rose-900/30'
                }`}>
                  {isCompliantGeofenced ? <Check size={12} /> : <ShieldAlert size={12} />}
                  <span>{isCompliantGeofenced ? t.insideGeofence : t.outsideGeofence}</span>
                </div>
              </div>

              {/* Selfie section inside Mobile App */}
              <div className="border border-slate-800/80 rounded-xl p-2.5 bg-slate-900/50 text-center space-y-2">
                <p className="text-[10px] text-slate-400 font-semibold">{t.selfieRequired}</p>
                
                {isCameraActive ? (
                  <div className="w-full h-32 bg-black rounded overflow-hidden relative">
                    <video ref={videoRef} className="w-full h-full object-cover" />
                    <button
                      onClick={captureSnapshot}
                      className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-indigo-600 hover:bg-indigo-700 text-white p-1 px-3 rounded text-[8px] font-bold cursor-pointer"
                    >
                      {lang === 'ar' ? 'التقاط الصورة' : 'Snap Photo'}
                    </button>
                  </div>
                ) : selfieSrc ? (
                  <div className="relative inline-block">
                    <img src={selfieSrc} alt="selfie" className="w-20 h-20 rounded-full object-cover border-2 border-indigo-500 mx-auto" />
                    <button
                      onClick={() => setSelfieSrc(null)}
                      className="absolute top-0 right-1/2 translate-x-10 p-1 bg-rose-600 text-white rounded-full hover:bg-rose-700"
                    >
                      <X size={10} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={startCamera}
                    className="flex items-center gap-1.5 mx-auto p-1.5 px-3 bg-slate-800 hover:bg-slate-705 text-slate-300 rounded-lg text-[10px] font-bold cursor-pointer"
                  >
                    <Camera size={12} />
                    {t.captureSelfie}
                  </button>
                )}
              </div>
            </div>

            {/* CheckIn Call action */}
            <button
              onClick={handleGPSCheckIn}
              className={`w-full py-2 px-4 rounded-xl text-xs font-bold transition mt-3 cursor-pointer ${
                isCompliantGeofenced ? 
                'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-900/10' : 
                'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              {lang === 'ar' ? 'ارسال تقرير الحضور (GPS)' : 'Submit CheckIn Position'}
            </button>
          </div>
        </div>

        {/* Configurations Parameters Workspace (Right Side) */}
        <div className="space-y-4">
          <div className="flex gap-2 items-center text-indigo-600 dark:text-indigo-400 mb-2">
            <Navigation size={22} className="animate-pulse" />
            <h4 className="text-sm font-bold">{lang === 'ar' ? 'معمل محاكاة وإعدادات الموقع الجغرافي للشبكة' : 'GPS Coordinates Simulator Sandbox'}</h4>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            {lang === 'ar' ? 
              'يمكنك التلاعب بإحداثيات العامل لمحاكاة تواجده قسرياً داخل موقع جاردن سيتي المعتمد (القاهرة) أو تواجده خارج نطاق الرصد لملاحظة ردة فعل جدار الحماية الجغرافي الذكي.' : 
              'Manipulate simulated staff placement nodes inside Cairo headquarters coordinates or shift bounds outside Cairo to test automated check-in Geofence denials.'}
          </p>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850 space-y-4">
            {/* Select Target Geofence project */}
            <div>
              <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{lang === 'ar' ? 'مشروع الرصد الجغرافي المستهدف' : 'Target Site Profile'}</label>
              <select
                value={targetSiteId}
                onChange={(e) => {
                  setTargetSiteId(e.target.value);
                  setStatusMsg(null);
                }}
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                {INITIAL_SITES.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            {/* Simulation Coordinates mode selector */}
            <div>
              <label className="block text-xxs text-slate-400 font-bold mb-2 uppercase">{lang === 'ar' ? 'الوضعية الجغرافية المحاكية' : 'Location placement Simulation mode'}</label>
              <div className="grid grid-cols-2 gap-2" id="sim-placement-radios">
                <button
                  onClick={() => handleCoordTypeChange('inside')}
                  className={`p-2 rounded-xl text-xxs font-bold border transition ${
                    coordType === 'inside' ? 
                    'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-900/10' : 
                    'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500'
                  }`}
                >
                  📍 {lang === 'ar' ? 'متواجد بموقع العمل (١٥ متر)' : 'On Site (15 m)'}
                </button>
                <button
                  onClick={() => handleCoordTypeChange('outside')}
                  className={`p-2 rounded-xl text-xxs font-bold border transition ${
                    coordType === 'outside' ? 
                    'bg-rose-50/20 dark:bg-rose-950/10 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-950/20' : 
                    'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500'
                  }`}
                >
                  🚗 {lang === 'ar' ? 'بعيداً عن الموقع (١.٨ كيلومتر)' : 'Too Far (1.8 KM)'}
                </button>
              </div>
            </div>

            {/* Simulated Latitude Longitude fields */}
            <div className="grid grid-cols-2 gap-3 text-mono text-xxs text-slate-500">
              <div>
                <span>SIMULATED LATITUDE</span>
                <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{customLat.toFixed(5)}</p>
              </div>
              <div>
                <span>SIMULATED LONGITUDE</span>
                <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{customLng.toFixed(5)}</p>
              </div>
            </div>
          </div>

          {/* Trigger Alert Messages */}
          {statusMsg && (
            <div className={`p-4 rounded-xl text-xs font-bold leading-relaxed border ${
              statusMsg.type === 'success' ? 
              'bg-emerald-50 dark:bg-slate-950 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-slate-850' : 
              'bg-rose-50/20 dark:bg-rose-950/5 text-rose-500 border-rose-100 dark:border-rose-950/15'
            }`} id="gps-status-tick">
              {statusMsg.text}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
