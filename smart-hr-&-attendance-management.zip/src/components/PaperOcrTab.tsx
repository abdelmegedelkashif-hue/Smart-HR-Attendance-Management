/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Employee, AttendanceRecord } from '../types';
import { translations } from '../translations';
import { Camera, Image, Check, RefreshCw, Sparkles, Edit, AlertCircle } from 'lucide-react';

interface PaperOcrTabProps {
  lang: 'ar' | 'en';
  employees: Employee[];
  attendance: AttendanceRecord[];
  setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
}

export const PaperOcrTab: React.FC<PaperOcrTabProps> = ({ lang, employees, attendance, setAttendance }) => {
  const t = translations[lang];

  // States
  const [imgBase64, setImgBase64] = useState<string | null>(null);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrRecords, setOcrRecords] = useState<any[]>([]);
  const [ocrMessage, setOcrMessage] = useState<string | null>(null);
  const [isAiMode, setIsAiMode] = useState(true);

  // File parsing base64 conversion
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImgBase64(reader.result as string);
        setOcrRecords([]);
        setOcrMessage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  // Preload demo hand-written sheet image
  const handleLoadDemoOcr = () => {
    // Elegant simulation mockup of manual sheets
    setImgBase64("DEMO_PAPER_SHEET_MOCK");
    setOcrRecords([]);
    setOcrMessage(null);
  };

  // Submit to Express backend AI OCR endpoint
  const executeOcrScanner = async () => {
    if (!imgBase64) return;
    setOcrLoading(true);
    setOcrMessage(null);

    try {
      // Send raw base64 or mockup to server
      const response = await fetch('/api/ocr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: imgBase64 === "DEMO_PAPER_SHEET_MOCK" ? 
            "MOCK_BASE64_OCR_SHEETS_MESSAGES_AND_STUFF" : imgBase64,
          mimeType: imgBase64 === "DEMO_PAPER_SHEET_MOCK" ? "image/png" : "image/jpeg"
        })
      });

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      setOcrRecords(result.extractedRecords || []);
      setOcrMessage(lang === 'ar' ? "نجح تفكيك كشف الحضور بالكامل عبر مستشعرات الذكاء الاصطناعي!" : "Table successfully digitized from sheet scan!");
    } catch (err: any) {
      console.error(err);
      setOcrMessage(lang === 'ar' ? `فشل النفاذ للذكاء الاصطناعي: ${err.message}` : `AI scan failed: ${err.message}`);
    } finally {
      setOcrLoading(false);
    }
  };

  // Local editing inside ocr verification list
  const handleOcrCellEdit = (index: number, field: string, value: string) => {
    setOcrRecords(ocrRecords.map((rec, idx) => {
      if (idx === index) {
        return { ...rec, [field]: value };
      }
      return rec;
    }));
  };

  // Commit and write logs to global list
  const handleCommitOcrLogs = () => {
    if (ocrRecords.length === 0) return;

    const formattedRecords: AttendanceRecord[] = ocrRecords.map((rec, idx) => {
      // Find matches in employees db to fetch precise ID & FullName
      const employee = employees.find(e => e.id === rec.employeeId || e.name.trim() === String(rec.employeeName).trim());
      
      const shiftsIn = parseTimeToMinutes(rec.checkIn || '08:00');
      const shiftsOut = parseTimeToMinutes(rec.checkOut || '16:00');
      
      const targetStart = 8 * 60; // 08:00
      const targetEnd = 16 * 60; // 16:00

      let delayMin = Math.max(0, shiftsIn - targetStart);
      let earlyLeave = Math.max(0, targetEnd - shiftsOut);
      let hoursWorked = Math.max(0, (shiftsOut - shiftsIn) / 60);
      let overtime = Math.max(0, (shiftsOut - targetEnd) / 60);

      let status: 'present' | 'late' | 'early_leave' | 'overtime' = 'present';
      if (overtime > 0) status = 'overtime';
      else if (delayMin > 15) status = 'late';
      else if (earlyLeave > 15) status = 'early_leave';

      return {
        id: `OCR-${Date.now()}-${idx}`,
        employeeId: employee ? employee.id : (rec.employeeId || `EMP-OCR-${idx + 10}`),
        employeeName: employee ? employee.name : rec.employeeName,
        date: rec.date || new Date().toISOString().split('T')[0],
        checkIn: rec.checkIn || '08:00',
        checkOut: rec.checkOut || '16:00',
        status,
        hoursWorked: parseFloat(hoursWorked.toFixed(2)),
        overtimeHours: parseFloat(overtime.toFixed(2)),
        delayMinutes: delayMin,
        earlyLeaveMinutes: earlyLeave,
        method: 'ocr'
      };
    });

    const existingIndexKeys = attendance.map(a => `${a.employeeId}_${a.date}`);
    const uniqueIncoming = formattedRecords.filter(inc => !existingIndexKeys.includes(`${inc.employeeId}_${inc.date}`));

    setAttendance([...attendance, ...uniqueIncoming]);
    setOcrMessage(lang === 'ar' ? 
      `تم إدراج وتسوية عدد ${uniqueIncoming.length} سجل من كشف الحضور المستخرج بالكامل!` : 
      `Successfully generated ${uniqueIncoming.length} unique attendance entries!`);
    setOcrRecords([]);
    setImgBase64(null);
  };

  const parseTimeToMinutes = (tStr: string) => {
    if (!tStr || !tStr.includes(':')) return 480;
    const [h, m] = tStr.split(':').map(Number);
    return h * 60 + m;
  };

  return (
    <div className="space-y-6" id="paper-ocr-container">
      {/* Upload workstation */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row gap-6">
        
        {/* Upload box */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/30 dark:bg-slate-950/20 text-center">
          <Camera className="text-slate-400 mb-2" size={32} />
          <h4 className="text-xs font-bold text-slate-800 dark:text-white mb-2">{lang === 'ar' ? 'رفع صور كشوف الحضور الورقية الموقعة' : 'Upload Manual Site Timesheet Paper Photos'}</h4>
          
          <div className="relative overflow-hidden inline-block px-4 py-2 bg-indigo-50 dark:bg-slate-950 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-400 font-bold text-xxs rounded-lg cursor-pointer transition">
            <span>{lang === 'ar' ? 'اختر صورة الكشف المكتوب أو المطبوع' : 'Select Sheet Photograph'}</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageFileChange}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>

          <button
            onClick={handleLoadDemoOcr}
            className="text-[10px] text-slate-400 hover:text-indigo-500 font-bold underline mt-3 bg-transparent border-none cursor-pointer"
          >
            {lang === 'ar' ? 'تحميل كشف ممسوح تجريبي (محاكاة)' : 'Preload handy handwritten sheet mockup'}
          </button>
        </div>

        {/* Selected image preview */}
        <div className="flex-1 border border-slate-150 dark:border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950/10 min-h-[220px]">
          {imgBase64 ? (
            <div className="w-full flex flex-col items-center">
              {imgBase64 === "DEMO_PAPER_SHEET_MOCK" ? (
                // Draw luxury handwritten demo sheet
                <div className="p-4 rounded border-2 border-amber-200 bg-amber-50/40 text-[10px] font-mono leading-relaxed shadow-inner max-w-xs text-slate-705 w-full">
                  <p className="font-bold border-b pb-1 mb-2 text-center text-amber-800">📋 كشف حضور عمال الموقع - ٢٠٢٦/٥/٣١ - يدوي</p>
                  <p>1. محمد علي جابر | 101 | دخ: 07:55 | خر: 16:02</p>
                  <p>2. أميرة محمود | 103 | دخ: 08:15 | خر: 16:00</p>
                  <p>3. خالد سعيد | 104 | دخ: 07:50 | خر: 17:30</p>
                  <p>4. ياسر رضوان | 105 | دخ: 08:45 | خر: 15:45</p>
                  <p className="text-[8px] text-slate-400 mt-2 text-center">** ختم موقع العاصمة الإدارية معتمد **</p>
                </div>
              ) : (
                <img
                  src={imgBase64}
                  alt="Scanned log"
                  className="max-h-48 rounded object-cover shadow border"
                />
              )}

              <button
                onClick={executeOcrScanner}
                disabled={ocrLoading}
                className="mt-4 flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xxs font-bold cursor-pointer transition"
              >
                {ocrLoading ? <RefreshCw className="animate-spin" size={12} /> : <Sparkles size={12} />}
                {ocrLoading ? (lang === 'ar' ? 'جاري قراءة كود الحروف واستخراج الجداول...' : 'Reading text structures via Gemini...') : (lang === 'ar' ? 'فك الشفرة واستخراج الجدول بالذكاء الاصطناعي' : 'Extract Spreadsheet via Gemini OCR')}
              </button>
            </div>
          ) : (
            <div className="text-center text-slate-400 text-xxs py-6">
              <Image size={24} className="mx-auto text-slate-300 mb-1" />
              {lang === 'ar' ? 'لم يتم تحميل أي صورة كشف بعد' : 'No document photograph staged.'}
            </div>
          )}
        </div>
      </div>

      {/* OCR Message Tickers */}
      {ocrMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-slate-950 text-emerald-600 dark:text-emerald-400 text-xxs font-bold border border-emerald-100 dark:border-slate-850 rounded-xl flex items-center gap-1.5">
          <Check size={14} />
          {ocrMessage}
        </div>
      )}

      {/* Side by side Verification editor */}
      {ocrRecords.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 animate-fadeIn">
          <div className="flex justify-between items-center pb-2 border-b border-slate-50 dark:border-slate-850">
            <div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 block"></span>
                {t.previewExtracted}
              </h4>
              <p className="text-xxs text-slate-400 mt-0.5">{lang === 'ar' ? 'يرجى مراجعة وتصفية التواقيت والتأريخ قبل توثيقها نهائياً بملفات السجلات العامة' : 'Review and correct manual logs before merging into permanent enterprise registers'}</p>
            </div>

            <button
              onClick={handleCommitOcrLogs}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xxs rounded-xl cursor-pointer"
            >
              <Check size={14} className="inline mr-1" />
              {lang === 'ar' ? 'اعتماد وحفظ السجلات المدققة' : 'Approve & Settle into Permanent Logs'}
            </button>
          </div>

          {/* Grid editor */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xxs" id="ocr-verification-table">
              <thead className="bg-slate-50 dark:bg-slate-950/40 text-slate-400 font-bold uppercase py-2">
                <tr>
                  <th className="p-3">{t.empId}</th>
                  <th className="p-3">{t.fullName}</th>
                  <th className="p-3 text-center">{lang === 'ar' ? 'تاريخ الكشف' : 'Log Date'}</th>
                  <th className="p-3 text-center">{lang === 'ar' ? 'وقت الدخول (HH:mm)' : 'Check In'}</th>
                  <th className="p-3 text-center">{lang === 'ar' ? 'وقت الخروج (HH:mm)' : 'Check Out'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-300">
                {ocrRecords.map((rec, index) => (
                  <tr key={index} className="hover:bg-slate-50/10">
                    <td className="p-2">
                      <input
                        type="text"
                        value={rec.employeeId || ''}
                        onChange={(e) => handleOcrCellEdit(index, 'employeeId', e.target.value)}
                        className="w-24 px-2 py-1 border border-slate-200 dark:border-slate-700 rounded bg-transparent font-mono text-indigo-500 font-bold uppercase"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        value={rec.employeeName || ''}
                        onChange={(e) => handleOcrCellEdit(index, 'employeeName', e.target.value)}
                        className="w-full max-w-xs px-2 py-1 border border-slate-200 dark:border-slate-700 rounded bg-transparent font-bold"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="text"
                        value={rec.date || ''}
                        onChange={(e) => handleOcrCellEdit(index, 'date', e.target.value)}
                        className="w-28 text-center px-2 py-1 border border-slate-200 dark:border-slate-700 rounded bg-transparent font-mono"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="text"
                        value={rec.checkIn || ''}
                        onChange={(e) => handleOcrCellEdit(index, 'checkIn', e.target.value)}
                        className="w-16 text-center px-2 py-1 border border-slate-200 dark:border-slate-700 rounded bg-transparent font-bold text-emerald-500 font-mono"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="text"
                        value={rec.checkOut || ''}
                        onChange={(e) => handleOcrCellEdit(index, 'checkOut', e.target.value)}
                        className="w-16 text-center px-2 py-1 border border-slate-200 dark:border-slate-700 rounded bg-transparent font-bold text-rose-500 font-mono"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
