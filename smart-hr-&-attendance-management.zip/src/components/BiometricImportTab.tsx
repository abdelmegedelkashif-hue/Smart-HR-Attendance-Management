/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Employee, AttendanceRecord } from '../types';
import { translations } from '../translations';
import { FileSpreadsheet, Upload, Check, AlertTriangle, RefreshCw, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';

interface BiometricImportTabProps {
  lang: 'ar' | 'en';
  employees: Employee[];
  attendance: AttendanceRecord[];
  setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
}

export const BiometricImportTab: React.FC<BiometricImportTabProps> = ({ lang, employees, attendance, setAttendance }) => {
  const t = translations[lang];

  // States
  const [bLoading, setBLoading] = useState(false);
  const [importedLogs, setImportedLogs] = useState<any[]>([]);
  const [matchedCount, setMatchedCount] = useState(0);
  const [unmatchedLogs, setUnmatchedLogs] = useState<any[]>([]);
  const [alertMsg, setAlertMsg] = useState<string | null>(null);

  // Parse excel helper
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setBLoading(true);
    setAlertMsg(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        
        processBiometricRows(data);
      } catch (err) {
        console.error(err);
        setAlertMsg(lang === 'ar' ? 'حدث خطأ أثناء فك تشفير كشوف ملف البصمة.' : 'Spreadsheet parsing exception occurred.');
        setBLoading(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  // Business parser logic
  const processBiometricRows = (rows: any[]) => {
    const validMatches: any[] = [];
    const missingKeys: any[] = [];

    rows.forEach((row: any) => {
      // Look for standard biometric outputs: Employee ID, Name, Date, Check In, Check Out
      const rowId = row['Employee ID'] || row['ID'] || row['رقم_البصمة'] || row['employeeId'];
      const rowName = row['Name'] || row['Employee Name'] || row['الاسم'] || row['employeeName'];
      const rowDate = row['Date'] || row['التاريخ'] || row['date'];
      const rawIn = row['Check In'] || row['In'] || row['الدخول'] || row['checkIn'];
      const rawOut = row['Check Out'] || row['Out'] || row['الخروج'] || row['checkOut'];

      if (!rowDate || !rowName) return;

      const employee = employees.find(e => e.id === rowId || e.name.trim() === String(rowName).trim());

      if (employee) {
        validMatches.push({
          id: `BIOM-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          employeeId: employee.id,
          employeeName: employee.name,
          date: String(rowDate),
          checkIn: String(rawIn || '08:00'),
          checkOut: String(rawOut || '16:00'),
          status: 'present',
          method: 'fingerprint'
        });
      } else {
        missingKeys.push({
          id: rowId || 'N/A',
          name: rowName,
          date: rowDate,
          checkIn: rawIn || 'N/A',
          checkOut: rawOut || 'N/A'
        });
      }
    });

    setImportedLogs(validMatches);
    setMatchedCount(validMatches.length);
    setUnmatchedLogs(missingKeys);
    setBLoading(false);
  };

  // Simulations preload loader
  const handleLoadSample = () => {
    setBLoading(true);
    setAlertMsg(null);
    setTimeout(() => {
      // Populate 4 realistic rows corresponding to active EMP list
      const mockRawRows = [
        { 'Employee ID': "EMP-101", 'Name': "محمد علي جابر", 'Date': "2026-05-31", 'Check In': "07:58", 'Check Out': "16:02" },
        { 'Employee ID': "EMP-102", 'Name': "أحمد ممدوح حسن", 'Date': "2026-05-31", 'Check In': "08:14", 'Check Out': "16:10" },
        { 'Employee ID': "EMP-103", 'Name': "أميرة محمود يوسف", 'Date': "2026-05-31", 'Check In': "07:55", 'Check Out': "15:45" },
        { 'Employee ID': "EMP-105", 'Name': "ياسر رضوان كمال", 'Date': "2026-05-31", 'Check In': "08:35", 'Check Out': "17:30" },
        { 'Employee ID': "BADGE-999", 'Name': "عامل خارجي مجهول", 'Date': "2026-05-31", 'Check In': "08:00", 'Check Out': "16:00" } // unmatched
      ];
      processBiometricRows(mockRawRows);
    }, 1200);
  };

  // Commit and merge logs into live registers database
  const handleCommitLogs = () => {
    if (importedLogs.length === 0) return;

    // Convert biometric simple schema into structured record files
    const newStructuredLogs: AttendanceRecord[] = importedLogs.map(log => {
      // hours & delay calculations
      const checkInMinutes = parseTimeToMinutes(log.checkIn);
      const checkOutMinutes = parseTimeToMinutes(log.checkOut);
      
      const shiftsStart = 8 * 60; // 08:00
      const shiftsEnd = 16 * 60; // 16:00

      let delayMin = 0;
      if (checkInMinutes > shiftsStart) {
        delayMin = checkInMinutes - shiftsStart;
      }

      let earlyLeave = 0;
      if (checkOutMinutes < shiftsEnd) {
        earlyLeave = shiftsEnd - checkOutMinutes;
      }

      // Base hours worked
      let hoursWorked = Math.max(0, (checkOutMinutes - checkInMinutes) / 60);
      let overtime = 0;
      if (checkOutMinutes > shiftsEnd) {
        overtime = (checkOutMinutes - shiftsEnd) / 60;
      }

      let status: 'present' | 'late' | 'early_leave' | 'overtime' = 'present';
      if (overtime > 0) status = 'overtime';
      else if (delayMin > 15) status = 'late';
      else if (earlyLeave > 15) status = 'early_leave';

      return {
        id: log.id,
        employeeId: log.employeeId,
        employeeName: log.employeeName,
        date: log.date,
        checkIn: log.checkIn,
        checkOut: log.checkOut,
        status,
        hoursWorked: parseFloat(hoursWorked.toFixed(2)),
        overtimeHours: parseFloat(overtime.toFixed(2)),
        delayMinutes: delayMin,
        earlyLeaveMinutes: earlyLeave,
        method: 'fingerprint'
      };
    });

    // Merge logs ensuring we skip duplicate (Employee + Date)
    const existingIndexKeys = attendance.map(a => `${a.employeeId}_${a.date}`);
    const uniqueIncoming = newStructuredLogs.filter(inc => !existingIndexKeys.includes(`${inc.employeeId}_${inc.date}`));
    
    setAttendance([...attendance, ...uniqueIncoming]);
    setAlertMsg(lang === 'ar' ? 
      `تم استيراد ${uniqueIncoming.length} سجل حضور جديد وتجاهل المكرر بنجاح!` : 
      `Successfully loaded ${uniqueIncoming.length} unique fingerprint events!`);
    
    setImportedLogs([]);
    setUnmatchedLogs([]);
  };

  // Parse "HH:mm" -> minutes since midnight
  const parseTimeToMinutes = (tStr: string) => {
    if (!tStr || !tStr.includes(':')) return 480;
    const [h, m] = tStr.split(':').map(Number);
    return h * 60 + m;
  };

  return (
    <div className="space-y-6" id="biometrics-import-container">
      {/* Visual Import Area */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-8 shadow-sm flex flex-col items-center justify-center text-center">
        <div className="p-4 bg-indigo-50 dark:bg-slate-950 text-indigo-600 dark:text-indigo-400 rounded-full mb-4">
          <FileSpreadsheet size={40} />
        </div>
        
        <h3 className="text-base font-bold text-slate-800 dark:text-white mb-1">
          {lang === 'ar' ? 'بوابة استيراد كشوف البصمة الإلكترونية' : 'Fingerprint Biometric Logs Uploader'}
        </h3>
        <p className="text-xs text-slate-400 max-w-lg mb-6 leading-relaxed">
          {t.importLimits}
        </p>

        {/* Drag Drop Wrapper */}
        <div className="relative border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-indigo-500 rounded-2xl p-6 w-full max-w-md transition duration-200 bg-slate-50/50 dark:bg-slate-950/20">
          <input
            type="file"
            onChange={handleFileUpload}
            accept=".xlsx, .xls, .csv"
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
          <Upload className="mx-auto text-slate-400 mb-2" size={28} />
          <span className="text-xs font-bold text-slate-500 dark:text-slate-300 block">{t.importDragText}</span>
        </div>

        {/* Simulations prompt */}
        <div className="mt-4 flex flex-wrap gap-3">
          <button
            onClick={handleLoadSample}
            id="preload-biometric-mock"
            className="text-xxs text-indigo-600 hover:text-indigo-700 font-bold underline bg-transparent border-none cursor-pointer"
          >
            {t.loadSample}
          </button>
        </div>
      </div>

      {/* Loading spinners */}
      {bLoading && (
        <div className="flex items-center justify-center gap-2 p-4 text-xs text-slate-500 font-medium">
          <RefreshCw className="animate-spin text-indigo-500" size={16} />
          <span>{lang === 'ar' ? 'جاري فك تشفير وتدقيق الصفوف...' : 'Checking and analyzing biometric card indices...'}</span>
        </div>
      )}

      {/* Alerts notification */}
      {alertMsg && (
        <div className="p-4 bg-emerald-50 dark:bg-slate-950 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-slate-850 rounded-xl text-xs font-bold leading-relaxed">
          {alertMsg}
        </div>
      )}

      {/* Verification grids blocks */}
      {(importedLogs.length > 0 || unmatchedLogs.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn" id="biometrics-reconciliation-grids">
          {/* Matched Panel (2 cols) */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  {t.matchedRecords} ({matchedCount})
                </h4>
                <p className="text-xxs text-slate-400 mt-0.5">{lang === 'ar' ? 'سجلات تم فحص الكود المنسوب ومطابقة الموظف المسجل' : 'Linked employee codes matching database indices'}</p>
              </div>

              <button
                onClick={handleCommitLogs}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xxs rounded-xl cursor-pointer transition flex items-center gap-1"
              >
                <Check size={14} />
                {lang === 'ar' ? 'اعتماد الكشف وإدراج السجلات' : 'Commit & Import Checked Rows'}
              </button>
            </div>

            <div className="overflow-x-auto max-h-64 border rounded-xl border-slate-50 dark:border-slate-850">
              <table className="w-full text-right text-xxs">
                <thead className="bg-slate-50 dark:bg-slate-950/30 text-slate-400 font-bold uppercase py-2">
                  <tr>
                    <th className="p-3">{t.empId}</th>
                    <th className="p-3">{t.fullName}</th>
                    <th className="p-3 text-center">{lang === 'ar' ? 'تاريخ البصمة' : 'Date'}</th>
                    <th className="p-3 text-center">{lang === 'ar' ? 'دخول' : 'In'}</th>
                    <th className="p-3 text-center">{lang === 'ar' ? 'خروج' : 'Out'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-600 dark:text-slate-300">
                  {importedLogs.map((log, index) => (
                    <tr key={index} className="hover:bg-slate-50/20">
                      <td className="p-3 font-mono text-indigo-500 font-semibold">{log.employeeId}</td>
                      <td className="p-3 font-bold">{log.employeeName}</td>
                      <td className="p-3 text-center">{log.date}</td>
                      <td className="p-3 text-center text-emerald-500 font-bold">{log.checkIn}</td>
                      <td className="p-3 text-center text-emerald-500 font-bold">{log.checkOut}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Unmatched logs warning panel */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-100 dark:border-rose-950/10 p-5 shadow-sm space-y-3">
            <h4 className="text-sm font-bold text-rose-500 flex items-center gap-1.5">
              <AlertTriangle size={18} className="glow-animation" />
              {t.unregisteredAlert} ({unmatchedLogs.length})
            </h4>
            <p className="text-xxs text-slate-400 leading-relaxed">
              {lang === 'ar' ? 
                'بصمات بطاقات إما غير مسجلة بقاعدة شؤون العاملين بالشركة أو تابعة لمقاولين من الباطن.' : 
                'Indices unrecognized inside database roster. Potential subcontract crew or registration errors.'}
            </p>

            <div className="overflow-y-auto max-h-60 border border-slate-150 dark:border-slate-850 rounded-xl p-2 space-y-2">
              {unmatchedLogs.map((log, idx) => (
                <div key={idx} className="p-2.5 bg-rose-50/20 dark:bg-rose-950/5 rounded-lg text-xxs border border-rose-100/30">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-rose-500 font-mono">ID: {log.id}</span>
                    <span className="text-[10px] text-slate-400">{log.date}</span>
                  </div>
                  <p className="font-semibold text-slate-700 dark:text-slate-300">{log.name || 'Anonymous'}</p>
                  <p className="text-slate-400 mt-1">Check-In: {log.checkIn} | Out: {log.checkOut}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
