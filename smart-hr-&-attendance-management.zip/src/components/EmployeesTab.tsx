/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Employee, EmployeeDocument } from '../types';
import { DEPARTMENTS, CONTRACT_TYPES, CONTRACT_TYPES_AR } from '../initialData';
import { translations } from '../translations';
import { Search, Plus, Edit2, Trash2, ShieldCheck, Mail, Phone, Calendar, ClipboardList, Printer, X, BadgePlus, UserMinus, ShieldAlert, FileSpreadsheet, Download, Upload } from 'lucide-react';

interface EmployeesTabProps {
  lang: 'ar' | 'en';
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
  triggerAddEmployee?: number;
}

export const EmployeesTab: React.FC<EmployeesTabProps> = ({ lang, employees, setEmployees, triggerAddEmployee }) => {
  const t = translations[lang];

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  
  // Modals & form state
  const [showModal, setShowModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [formEmpId, setFormEmpId] = useState('');
  const [formName, setFormName] = useState('');
  const [formNationalId, setFormNationalId] = useState('');
  const [formPosition, setFormPosition] = useState('');
  const [formDepartment, setFormDepartment] = useState('');
  const [formProjectSite, setFormProjectSite] = useState('');
  const [formHireDate, setFormHireDate] = useState('');
  const [formSalary, setFormSalary] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formContractType, setFormContractType] = useState<'Full-time' | 'Part-time' | 'Contract' | 'Daily'>('Full-time');
  const [formStatus, setFormStatus] = useState<'active' | 'suspended'>('active');
  const [formAvatar, setFormAvatar] = useState('/assets/placeholder-person.jpg');

  // Badge Display modal
  const [showBadgeId, setShowBadgeId] = useState<string | null>(null);

  // Filter logic
  const filteredEmployees = employees.filter(emp => {
    const matchesKeyword = emp.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           emp.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           emp.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === '' || emp.department === selectedDept;
    return matchesKeyword && matchesDept;
  });

  // Photo uploader preset base64 simulation
  const handlePhotoSimulation = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Open modal for adding
  const openAddModal = () => {
    setIsEditMode(false);
    const nextId = `EMP-${100 + employees.length + 1}`;
    setFormEmpId(nextId);
    setFormName('');
    setFormNationalId('');
    setFormPosition('');
    setFormDepartment(DEPARTMENTS[0]);
    setFormProjectSite('المقر الرئيسي - جاردن سيتي، القاهرة');
    setFormHireDate(new Date().toISOString().split('T')[0]);
    setFormSalary('8000');
    setFormPhone('');
    setFormContractType('Full-time');
    setFormStatus('active');
    setFormAvatar('https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80');
    setShowModal(true);
  };

  // Automatically open on external quick trigger
  useEffect(() => {
    if (triggerAddEmployee && triggerAddEmployee > 0) {
      openAddModal();
    }
  }, [triggerAddEmployee]);

  // Open modal for editing
  const openEditModal = (emp: Employee) => {
    setIsEditMode(true);
    setFormEmpId(emp.id);
    setFormName(emp.name);
    setFormNationalId(emp.nationalId);
    setFormPosition(emp.position);
    setFormDepartment(emp.department);
    setFormProjectSite(emp.projectSite);
    setFormHireDate(emp.hireDate);
    setFormSalary(emp.salary.toString());
    setFormPhone(emp.phone);
    setFormContractType(emp.contractType);
    setFormStatus(emp.status);
    setFormAvatar(emp.avatar);
    setShowModal(true);
  };

  // Save changes
  const handleSaveEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone || !formPosition) {
      alert(lang === 'ar' ? "يرجى ملء كافة الخانات الهامة" : "Ensure all mandatory fields are supplied.");
      return;
    }

    const payload: Employee = {
      id: formEmpId,
      name: formName,
      nationalId: formNationalId || "29001010102431",
      position: formPosition,
      department: formDepartment,
      projectSite: formProjectSite,
      hireDate: formHireDate,
      salary: parseFloat(formSalary) || 8000,
      contractType: formContractType,
      phone: formPhone,
      avatar: formAvatar,
      status: formStatus,
      documents: isEditMode ? (employees.find(e => e.id === formEmpId)?.documents || []) : []
    };

    if (isEditMode) {
      setEmployees(employees.map(emp => emp.id === formEmpId ? payload : emp));
    } else {
      setEmployees([...employees, payload]);
    }
    setShowModal(false);
  };

  // Delete employee
  const handleDeleteEmployee = (id: string) => {
    if (confirm(lang === 'ar' ? `هل أنت متأكد من حذف الموظف ذو الرقم ${id}؟` : `Delete employee ${id} permanently?`)) {
      setEmployees(employees.filter(emp => emp.id !== id));
    }
  };

  // Toggle status directly
  const toggleStatus = (id: string) => {
    setEmployees(employees.map(emp => {
      if (emp.id === id) {
        return { ...emp, status: emp.status === 'active' ? 'suspended' : 'active' };
      }
      return emp;
    }));
  };

  const activeBadgeEmp = employees.find(e => e.id === showBadgeId);

  // EXCEL / CSV EXPORT UTILITY
  const exportToExcel = () => {
    const headers = lang === 'ar' ? 
      ['معرف الموظف', 'الاسم الكامل', 'الرقم القومي', 'المسمى الوظيفي', 'القسم', 'موقع المشروع', 'تاريخ التعيين', 'الراتب', 'نوع التعاقد', 'رقم الهاتف', 'الحالة'] :
      ['Employee ID', 'Full Name', 'National ID', 'Position', 'Department', 'Project Site', 'Hire Date', 'Salary', 'Contract Type', 'Phone', 'Status'];

    const rows = employees.map(emp => [
      emp.id,
      emp.name,
      emp.nationalId,
      emp.position,
      emp.department,
      emp.projectSite,
      emp.hireDate,
      emp.salary,
      emp.contractType,
      emp.phone,
      emp.status
    ]);

    const csvContent = "sep=,\n" + [
      headers.join(','),
      ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `employees_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // EXCEL / CSV TEMPLATE DOWNLOAD HELPERS
  const downloadTemplate = () => {
    const headers = lang === 'ar' ? 
      ['معرف الموظف', 'الاسم الكامل', 'الرقم القومي', 'المسمى الوظيفي', 'القسم', 'موقع المشروع', 'تاريخ التعيين', 'الراتب', 'نوع العقد', 'رقم الهاتف', 'الحالة'] :
      ['Employee ID', 'Full Name', 'National ID', 'Position', 'Department', 'Project Site', 'Hire Date', 'Salary', 'Contract Type', 'Phone', 'Status'];

    const sampleRow = lang === 'ar' ? 
      ['EMP-999', 'محمد عبد الرحمن محمود', '29402120102456', 'مهندس برمجيات شريك', 'الهندسة والبرمجيات', 'المقر الرئيسي - جاردن سيتي، القاهرة', '2026-01-15', '18000', 'Full-time', '01012345678', 'active'] :
      ['EMP-999', 'Mohamed Abdelrahman', '29402120102456', 'Senior Software Engineer', 'Engineering', 'Main Headquarters', '2026-01-15', '18000', 'Full-time', '01012345678', 'active'];

    const csvContent = "sep=,\n" + [
      headers.join(','),
      sampleRow.map(val => `"${String(val).replace(/"/g, '""')}"`).join(',')
    ].join('\n');

    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `employees_import_template.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // EXCEL / CSV IMPORT UTILITY
  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
        
        let startIndex = 0;
        if (lines[0].startsWith('sep=')) {
          startIndex = 1;
        }
        
        const dataLines = lines.slice(startIndex + 1);
        const newEmployees: Employee[] = [];
        
        for (const line of dataLines) {
          const matches = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || line.split(',');
          if (!matches || matches.length < 2) continue;
          
          const cleanValues = matches.map(val => val.replace(/^["']|["']$/g, '').trim());
          const name = cleanValues[1];
          if (!name) continue;
          
          const id = cleanValues[0] || `EMP-${100 + employees.length + newEmployees.length + 1}`;
          const nationalId = cleanValues[2] || '29001010102431';
          const position = cleanValues[3] || (lang === 'ar' ? 'عامل متكامل' : 'General Tech Worker');
          const department = cleanValues[4] || DEPARTMENTS[0];
          const projectSite = cleanValues[5] || 'المقر الرئيسي';
          const hireDate = cleanValues[6] || new Date().toISOString().split('T')[0];
          const salary = parseFloat(cleanValues[7]) || 8000;
          const contractTypeRaw = cleanValues[8] || 'Full-time';
          const phone = cleanValues[9] || '01000000000';
          const statusRaw = cleanValues[10] || 'active';
          
          const contractType: 'Full-time' | 'Part-time' | 'Contract' | 'Daily' = 
            ['Full-time', 'Part-time', 'Contract', 'Daily'].includes(contractTypeRaw) 
            ? contractTypeRaw as any 
            : 'Full-time';
            
          const status: 'active' | 'suspended' = 
            ['active', 'suspended'].includes(statusRaw) ? statusRaw as any : 'active';

          newEmployees.push({
            id,
            name,
            nationalId,
            position,
            department,
            projectSite,
            hireDate,
            salary,
            contractType,
            phone,
            status,
            avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=128&q=80',
            documents: []
          });
        }

        if (newEmployees.length > 0) {
          setEmployees(prev => {
            const map = new Map(prev.map(item => [item.id, item]));
            newEmployees.forEach(emp => {
              map.set(emp.id, emp);
            });
            return Array.from(map.values());
          });
          
          alert(lang === 'ar' 
            ? `تم استيراد ${newEmployees.length} موظفاً وتغذيتهم للسحاب بنجاح` 
            : `Successfully imported ${newEmployees.length} employees directly to your Cloud HR Registry.`);
        } else {
          alert(lang === 'ar' ? "لم يتم العثور على أي موظفين صالحين بالملف" : "No valid employee records found in CSV grid.");
        }
      } catch (err) {
        console.error(err);
        alert(lang === 'ar' ? "فشل قراءة الملف" : "Unable to read raw records. Check Excel sheet structure.");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6" id="employees-tab-content">
      {/* Header controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Keyword Search */}
          <div className="relative w-full sm:w-60">
            <Search className="absolute right-3 top-2.5 text-slate-400" size={18} />
            <input
              type="text"
              placeholder={t.search}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Department Filter */}
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
          >
            <option value="">{lang === 'ar' ? 'تصفية حسب الأقسام' : 'All Departments'}</option>
            {DEPARTMENTS.map((dept, index) => (
              <option key={index} value={dept}>{dept}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Export to Excel */}
          <button
            onClick={exportToExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-950/60 rounded-xl text-xs font-bold border border-emerald-200/50 dark:border-emerald-800 transition-colors cursor-pointer select-none"
            title={lang === 'ar' ? 'تصدير كافة الموظفين إلى ملف إكسيل' : 'Export all employees to Excel'}
          >
            <Download size={15} />
            <span>{lang === 'ar' ? 'تصدير إكسيل' : 'Export Excel'}</span>
          </button>

          {/* Import from Excel / CSV */}
          <label className="flex items-center gap-1.5 px-3 py-2 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer select-none">
            <Upload size={15} />
            <span>{lang === 'ar' ? 'استيراد إكسيل' : 'Import Excel'}</span>
            <input 
              type="file" 
              accept=".csv" 
              onChange={handleExcelImport} 
              className="hidden" 
            />
          </label>

          {/* Download Template */}
          <button
            onClick={downloadTemplate}
            className="flex items-center gap-1 px-2.5 py-2 text-slate-400 dark:text-slate-500 hover:text-slate-650 dark:hover:text-slate-300 text-xs font-medium cursor-pointer select-none"
            title={lang === 'ar' ? 'تحميل نموذج الملف لبيانات الموظفين' : 'Download spreadsheet template'}
          >
            <FileSpreadsheet size={14} />
            <span className="underline decoration-dotted">{lang === 'ar' ? 'النموذج المرجعي' : 'Template'}</span>
          </button>

          <button
            onClick={openAddModal}
            id="btn-add-employee"
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow-md shadow-indigo-500/10"
          >
            <Plus size={15} />
            {t.add}
          </button>
        </div>
      </div>

      {/* Employees Grid list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="employees-grid">
        {filteredEmployees.map(emp => (
          <div
            key={emp.id}
            id={`employee-card-${emp.id}`}
            className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border shadow-sm transition duration-300 hover:shadow-md flex flex-col justify-between ${
              emp.status === 'suspended' ? 'border-rose-200 dark:border-rose-950/40 bg-rose-50/10' : 'border-slate-100 dark:border-slate-800'
            }`}
          >
            {/* Upper profile content */}
            <div>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={emp.avatar}
                    alt={emp.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-slate-100 dark:border-slate-800"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=128&q=80";
                    }}
                  />
                  <div>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1.5 flex-wrap">
                      {emp.name}
                      {emp.status === 'suspended' && (
                        <span className="text-xxs px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-500 font-bold">
                          {t.suspended}
                        </span>
                      )}
                    </h4>
                    <span className="text-xxs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full mt-1 inline-block">
                      {emp.id}
                    </span>
                  </div>
                </div>

                <span className={`text-xxs px-2.5 py-1 rounded-full font-semibold ${
                  emp.contractType === 'Full-time' ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400' :
                  emp.contractType === 'Daily' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400' :
                  'bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400'
                }`}>
                  {CONTRACT_TYPES_AR[emp.contractType as keyof typeof CONTRACT_TYPES_AR] || emp.contractType}
                </span>
              </div>

              {/* Personnel specs list */}
              <div className="mt-4 space-y-2 text-xs border-t border-slate-50 dark:border-slate-800/40 pt-4">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span className="font-semibold text-slate-400">{t.position}</span>
                  <span className="truncate max-w-44 text-right">{emp.position}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span className="font-semibold text-slate-400">{t.department}</span>
                  <span className="truncate max-w-44 text-right">{emp.department.replace(/\(.*\)/, '').trim()}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span className="font-semibold text-slate-400">{t.projectSite}</span>
                  <span className="truncate max-w-44 text-right text-indigo-500 dark:text-indigo-400 font-medium">{emp.projectSite.split('-')[0].trim()}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span className="font-semibold text-slate-400">{t.phone}</span>
                  <span className="ltr font-mono">{emp.phone}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400 font-semibold text-slate-800 dark:text-slate-200">
                  <span className="text-slate-400 font-normal">{t.salary}</span>
                  <span>{emp.salary.toLocaleString()} EGP</span>
                </div>
              </div>
            </div>

            {/* Quick Actions Row */}
            <div className="flex justify-between items-center mt-5 pt-3 border-t border-slate-50 dark:border-slate-805 bg-slate-50/50 dark:bg-slate-950/20 -mx-5 -mb-5 p-4 rounded-b-2xl">
              <button
                onClick={() => setShowBadgeId(emp.id)}
                className="flex items-center gap-1.5 text-slate-500 hover:text-indigo-600 font-bold text-xxs cursor-pointer"
              >
                <Printer size={13} />
                {lang === 'ar' ? 'البطاقة التعريفية' : 'Badge Card'}
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleStatus(emp.id)}
                  title={emp.status === 'active' ? t.suspended : t.active}
                  className={`p-1.5 rounded-lg border ${
                    emp.status === 'active' ? 
                    'text-amber-500 border-amber-100 dark:border-amber-950/30 hover:bg-amber-50 dark:hover:bg-amber-950/20' : 
                    'text-emerald-500 border-emerald-100 dark:border-emerald-950/30 hover:bg-emerald-50 dark:hover:bg-emerald-950/20'
                  }`}
                >
                  <ShieldAlert size={14} />
                </button>
                <button
                  onClick={() => openEditModal(emp)}
                  className="p-1.5 text-blue-500 rounded-lg border border-blue-100 dark:border-blue-955/30 hover:bg-blue-50 dark:hover:bg-blue-950/20"
                >
                  <Edit2 size={14} />
                </button>
                <button
                  onClick={() => handleDeleteEmployee(emp.id)}
                  className="p-1.5 text-rose-500 rounded-lg border border-rose-100 dark:border-rose-955/30 hover:bg-rose-50 dark:hover:bg-rose-950/20"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Corporate Badge Print Modal */}
      {activeBadgeEmp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" id="badge-modal">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl max-w-sm w-full p-6 relative">
            <button
              onClick={() => setShowBadgeId(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X size={20} />
            </button>

            <h3 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-1">
              <ClipboardList size={16} />
              {lang === 'ar' ? 'البطاقة الذكية للموظف' : 'Smart Corporate Badge'}
            </h3>

            {/* Print Section (Badges Layout) */}
            <div className="p-6 rounded-2xl bg-white text-slate-800 border-2 border-indigo-600 shadow-xl flex flex-col items-center text-center relative overflow-hidden" id="corporate-badge-printable">
              {/* Header Logo */}
              <div className="w-full bg-gradient-to-r from-indigo-700 to-indigo-900 text-white text-[10px] font-bold py-1.5 uppercase tracking-wide rounded-t-lg -mt-6 -mx-6 mb-4">
                Smart HRMS Security Pass
              </div>

              {/* Top Watermark Circle */}
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-indigo-500 shadow-md">
                <img
                  src={activeBadgeEmp.avatar}
                  alt={activeBadgeEmp.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <h2 className="text-base font-bold text-slate-900 mt-2">{activeBadgeEmp.name}</h2>
              <p className="text-xxs text-slate-500 font-semibold">{activeBadgeEmp.position}</p>

              {/* Barcode Mockups info */}
              <div className="mt-4 border-t border-b border-slate-100 py-3 w-full grid grid-cols-2 text-[10px] text-slate-600 font-medium">
                <div className="border-r border-slate-100">
                  <p className="text-xxs text-slate-400">{t.empId}</p>
                  <p className="font-bold text-slate-800 font-mono text-xs">{activeBadgeEmp.id}</p>
                </div>
                <div>
                  <p className="text-xxs text-slate-400">{t.department}</p>
                  <p className="font-bold text-slate-800 truncate px-1">{activeBadgeEmp.department.replace(/\(.*\)/, '').trim()}</p>
                </div>
              </div>

              {/* Bottom NFC mock strip */}
              <div className="mt-4 w-full flex flex-col items-center">
                {/* Simulated Barcode */}
                <div className="h-8 bg-slate-950 w-full rounded flex items-center justify-around px-2 py-1 select-none font-mono text-[9px] text-[#22c55e] tracking-widest gap-0.5">
                  ||||| | ||||| ||| ||| | |||
                </div>
                <p className="text-[8px] text-slate-400 mt-1 font-mono">{activeBadgeEmp.nationalId}</p>
              </div>

              {/* Corporate seal logo */}
              <div className="absolute bottom-1 right-2 w-9 h-9 border border-indigo-100 rounded-full flex items-center justify-center text-[7px] font-bold text-indigo-400 -rotate-12 opacity-30 select-none">
                HR Approved
              </div>
            </div>

            {/* Print trigger button */}
            <div className="mt-6 flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2 px-4 rounded-xl cursor-pointer transition"
              >
                <Printer size={16} />
                {lang === 'ar' ? 'أمر الطباعة الفورية' : 'Execute Print'}
              </button>
              <button
                onClick={() => setShowBadgeId(null)}
                className="px-4 py-2 border border-slate-700 hover:border-slate-600 text-slate-400 hover:text-white rounded-xl text-xs"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Employee Form Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm shadow-xl" id="employee-modal">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white rounded-2xl max-w-lg w-full p-6 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white"
            >
              <X size={20} />
            </button>

            <h3 className="text-base font-bold mb-4">
              {isEditMode ? (lang === 'ar' ? 'تعديل بيانات الموظف' : 'Modify Employee Specs') : (lang === 'ar' ? 'إضافة بطاقة موظف جديد' : 'Enroll New Corporate Staff')}
            </h3>

            <form onSubmit={handleSaveEmployee} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {/* ID */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.empId}</label>
                  <input
                    type="text"
                    disabled
                    value={formEmpId}
                    className="w-full bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-500 font-mono"
                  />
                </div>
                {/* Status */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.status}</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as 'active' | 'suspended')}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
                  >
                    <option value="active">{t.active}</option>
                    <option value="suspended">{t.suspended}</option>
                  </select>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.fullName} *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="محمد عبد العزيز حسن"
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* National ID */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.nationalId}</label>
                  <input
                    type="text"
                    maxLength={14}
                    value={formNationalId}
                    onChange={(e) => setFormNationalId(e.target.value)}
                    placeholder="29012010101234"
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                {/* Phone */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.phone} *</label>
                  <input
                    type="text"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="01012345678"
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Position */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.position} *</label>
                  <input
                    type="text"
                    required
                    value={formPosition}
                    onChange={(e) => setFormPosition(e.target.value)}
                    placeholder="مهندس إنشائي"
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                {/* Salary */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.salary} (EGP)</label>
                  <input
                    type="number"
                    value={formSalary}
                    onChange={(e) => setFormSalary(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Department */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.department}</label>
                  <select
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
                  >
                    {DEPARTMENTS.map((dept, index) => (
                      <option key={index} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                {/* Contract Category */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.contractType}</label>
                  <select
                    value={formContractType}
                    onChange={(e) => setFormContractType(e.target.value as any)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
                  >
                    {CONTRACT_TYPES.map((type, index) => (
                      <option key={index} value={type}>{CONTRACT_TYPES_AR[type as keyof typeof CONTRACT_TYPES_AR] || type}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Hire Date */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.hireDate}</label>
                  <input
                    type="date"
                    value={formHireDate}
                    onChange={(e) => setFormHireDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                  />
                </div>
                {/* Upload Photo Button */}
                <div>
                  <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{lang === 'ar' ? 'صورة الموظف' : 'Badging Photograph'}</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoSimulation}
                    className="w-full text-xxs text-slate-500 file:mr-4 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xxs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                  />
                </div>
              </div>

              {/* Save/Cancel controls */}
              <div className="flex gap-2 justify-end mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-950 text-slate-500 rounded-xl text-xs"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
