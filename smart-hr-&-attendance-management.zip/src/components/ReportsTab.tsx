/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AttendanceRecord, Employee } from '../types';
import { INITIAL_SITES } from '../initialData';
import { translations } from '../translations';
import { Search, Printer, Calendar, FileDown, Layers, CheckCircle } from 'lucide-react';

interface ReportsTabProps {
  lang: 'ar' | 'en';
  attendance: AttendanceRecord[];
  employees: Employee[];
}

export const ReportsTab: React.FC<ReportsTabProps> = ({ lang, attendance, employees }) => {
  const t = translations[lang];

  // States
  const [filterName, setFilterName] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterSite, setFilterSite] = useState('');
  const [startDate, setStartDate] = useState('2026-05-29'); // default dates showing initial logs
  const [endDate, setEndDate] = useState('2026-05-31');

  // Multi Filtering logic
  const filteredLogs = attendance.filter(rec => {
    // keyword Match
    const matchesKeyword = rec.employeeName.toLowerCase().includes(filterName.toLowerCase()) || 
                           rec.employeeId.toLowerCase().includes(filterName.toLowerCase());
    
    // Status Match
    const matchesStatus = filterStatus === '' || rec.status === filterStatus;

    // Date range Match
    const matchesDate = rec.date >= startDate && rec.date <= endDate;

    // Site geolocation match if present
    let matchesSite = true;
    if (filterSite !== '') {
      const empInstance = employees.find(e => e.id === rec.employeeId);
      matchesSite = empInstance?.projectSite === filterSite || rec.gpsLocation?.siteName === filterSite;
    }

    return matchesKeyword && matchesStatus && matchesDate && matchesSite;
  });

  // Export CSV mock trigger
  const handleExportCSV = () => {
    try {
      // Create headers
      const csvHeaders = "ID,Employee Name,Date,Check In,Check Out,Status,Hours Worked,Overtime Hours,Delay Minutes,Check Method\n";
      let csvContent = "data:text/csv;charset=utf-8," + csvHeaders;

      filteredLogs.forEach(rec => {
        const row = `"${rec.id}","${rec.employeeName}","${rec.date}","${rec.checkIn}","${rec.checkOut}","${rec.status}",${rec.hoursWorked},${rec.overtimeHours},${rec.delayMinutes},"${rec.method}"\n`;
        csvContent += row;
      });

      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `Attendance_Report_${startDate}_to_${endDate}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error(err);
      alert("CSV download exception.");
    }
  };

  const getStatusLabelText = (status: string) => {
    if (lang === 'ar') {
      switch (status) {
        case 'present': return 'حاضر';
        case 'late': return 'متأخر';
        case 'early_leave': return 'خروج مبكر';
        case 'overtime': return 'عمل إضافي';
        default: return 'غياب';
      }
    } else {
      switch (status) {
        case 'present': return 'Present';
        case 'late': return 'Late Arrival';
        case 'early_leave': return 'Early Leave';
        case 'overtime': return 'Overtime shift';
        default: return 'Absent';
      }
    }
  };

  return (
    <div className="space-y-6" id="reports-tab-container">
      {/* Filtering workstation block */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">{lang === 'ar' ? 'معايير تصفية وتوليد التقارير الموثقة' : 'Advanced Log Filtration Criteria'}</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Employee Name search */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-1 uppercase font-semibold">{lang === 'ar' ? 'بحث العامل' : 'Employee Key'}</label>
            <div className="relative">
              <Search className="absolute right-2.5 top-2 text-slate-400" size={14} />
              <input
                type="text"
                placeholder="EMP-101..."
                value={filterName}
                onChange={(e) => setFilterName(e.target.value)}
                className="w-full pr-8 pl-2 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
              />
            </div>
          </div>

          {/* Site Selection */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-1 uppercase font-semibold">{lang === 'ar' ? 'مستند المشروع' : 'Site Location'}</label>
            <select
              value={filterSite}
              onChange={(e) => setFilterSite(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-705 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
            >
              <option value="">{lang === 'ar' ? 'كل مواقع العمل المتاحة' : 'All Project Sites'}</option>
              {INITIAL_SITES.map((site, index) => (
                <option key={index} value={site.name}>{site.name}</option>
              ))}
            </select>
          </div>

          {/* Compliance Status selector */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-1 uppercase font-semibold">{t.status}</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-705 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
            >
              <option value="">{lang === 'ar' ? 'كل حالات الانضباط' : 'All status logs'}</option>
              <option value="present">{lang === 'ar' ? 'منضبط (حضور اعتيادي)' : 'Standard present'}</option>
              <option value="overtime">{lang === 'ar' ? 'محتسب ساعات إضافية' : 'Overtime'}</option>
              <option value="late">{lang === 'ar' ? 'سجل تأخير صباحي' : 'Delayed checkin'}</option>
              <option value="early_leave">{lang === 'ar' ? 'خروج مبكر عن الوردية' : 'Early exit'}</option>
            </select>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-1 uppercase font-semibold">{lang === 'ar' ? 'من تاريخ' : 'From Date'}</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-705 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
            />
          </div>

          {/* End Date */}
          <div>
            <label className="block text-[10px] text-slate-400 mb-1 uppercase font-semibold">{lang === 'ar' ? 'إلى تاريخ' : 'To Date'}</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-705 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
            />
          </div>
        </div>

        {/* Buttons Action triggers row */}
        <div className="flex gap-2 justify-end pt-2 border-t border-slate-50 dark:border-slate-850/30">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-205 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition"
          >
            <FileDown size={14} />
            {t.exportExcel}
          </button>
          
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer transition"
          >
            <Printer size={14} />
            {t.print}
          </button>
        </div>
      </div>

      {/* Printable spreadsheet list rendering */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden" id="attendance-report-records-grid">
        {/* Report Header for printing */}
        <div className="hidden print:block p-8 border-b text-center space-y-2 text-slate-900">
          <h2 className="text-xl font-bold uppercase">{t.appTitle}</h2>
          <p className="text-xs text-slate-500">Corporate Staff attendance list & Overtime Logs Summary Report</p>
          <p className="text-xxs text-slate-400 font-mono">Scope Parameters: {startDate} to {endDate} • Output size: {filteredLogs.length} Records</p>
        </div>

        <div className="p-4 bg-slate-50 dark:bg-slate-950/20 text-xxs text-slate-400 flex justify-between items-center font-bold">
          <span>{lang === 'ar' ? 'سجلات كشف الحضور المطابقة للمحدد' : 'FILTRATION COMPLIANT ENTRIES MATCH'}</span>
          <span className="bg-indigo-100 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-bold">{filteredLogs.length} {lang === 'ar' ? 'سجل تصفية' : 'Entries'}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 dark:bg-slate-950/50 text-slate-400 font-semibold uppercase py-2.5">
              <tr>
                <th className="p-3">{t.empId}</th>
                <th className="p-3">{t.fullName}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'اليوم والتاريخ' : 'Date'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'توقيت الحضور' : 'In'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'توقيت الانصراف' : 'Out'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'ساعات العمل' : 'Work Hours'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'الإضافي (ساعة)' : 'OT Hours'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'التأخير (دقيقة)' : 'Delay (mins)'}</th>
                <th className="p-3 text-center">{lang === 'ar' ? 'تكنولوجيا الإثبات' : 'Verification Method'}</th>
                <th className="p-3 text-center">{t.status}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
              {filteredLogs.map(rec => (
                <tr key={rec.id} className="hover:bg-slate-50/40 dark:hover:bg-slate-950/20 text-slate-600 dark:text-slate-300">
                  <td className="p-3 font-mono text-indigo-500 font-bold">{rec.employeeId}</td>
                  <td className="p-3 font-bold">{rec.employeeName}</td>
                  <td className="p-3 text-center font-mono font-semibold">{rec.date}</td>
                  <td className="p-3 text-center font-semibold text-emerald-500">{rec.checkIn || '--:--'}</td>
                  <td className="p-3 text-center font-semibold text-rose-500">{rec.checkOut || '--:--'}</td>
                  <td className="p-3 text-center font-mono">{rec.hoursWorked}</td>
                  <td className="p-3 text-center text-emerald-500 font-bold font-mono">
                    {rec.overtimeHours > 0 ? `+${rec.overtimeHours}` : '0'}
                  </td>
                  <td className="p-3 text-center text-amber-500 font-bold font-mono">
                    {rec.delayMinutes > 0 ? `${rec.delayMinutes} m` : '0'}
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-0.5 text-[8px] font-bold rounded uppercase ${
                      rec.method === 'fingerprint' ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' :
                      rec.method === 'gps' ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-600' : 'bg-pink-50 text-pink-500'
                    }`}>
                      {rec.method}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      rec.status === 'overtime' ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600' :
                      rec.status === 'late' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-500' :
                      rec.status === 'early_leave' ? 'bg-rose-50/20 dark:bg-rose-950/15 text-rose-500' :
                      'bg-slate-100 text-slate-500 dark:bg-slate-850'
                    }`}>
                      {getStatusLabelText(rec.status)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
