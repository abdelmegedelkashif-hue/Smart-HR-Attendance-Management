/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DailyLaborWorker } from '../types';
import { INITIAL_SITES } from '../initialData';
import { translations } from '../translations';
import { Search, Plus, Calendar, Coins, UserCheck, Trash2, Printer, X, ShieldAlert, BadgeMinus } from 'lucide-react';

interface DailyLaborTabProps {
  lang: 'ar' | 'en';
  dailyLabor: DailyLaborWorker[];
  setDailyLabor: React.Dispatch<React.SetStateAction<DailyLaborWorker[]>>;
}

export const DailyLaborTab: React.FC<DailyLaborTabProps> = ({ lang, dailyLabor, setDailyLabor }) => {
  const t = translations[lang];

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSite, setSelectedSite] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPayoutId, setShowPayoutId] = useState<string | null>(null);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formDailyRate, setFormDailyRate] = useState('150');
  const [formSiteName, setFormSiteName] = useState(INITIAL_SITES[0].name);

  // Click date log helper
  const [selectedLogWorker, setSelectedLogWorker] = useState<string | null>(null);
  const [logDateInput, setLogDateInput] = useState(new Date().toISOString().split('T')[0]);

  // Filters
  const filteredLabor = dailyLabor.filter(worker => {
    const matchesKeyword = worker.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           worker.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSite = selectedSite === '' || worker.siteName === selectedSite;
    return matchesKeyword && matchesSite;
  });

  // Toggle register working date
  const handleToggleDay = (workerId: string, dateStr: string) => {
    setDailyLabor(dailyLabor.map(worker => {
      if (worker.id === workerId) {
        const hasWorkDate = worker.activeDays.includes(dateStr);
        const nextDates = hasWorkDate ? 
          worker.activeDays.filter(d => d !== dateStr) : 
          [...worker.activeDays, dateStr];
        return { ...worker, activeDays: nextDates };
      }
      return worker;
    }));
  };

  // Add Worker
  const handleAddWorker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) {
      alert(lang === 'ar' ? "يرجى تعبئة اسم العامل ورقم هاتفه" : "Supply name and phone.");
      return;
    }

    const payload: DailyLaborWorker = {
      id: `LAB-${100 + dailyLabor.length + 1}`,
      name: formName,
      phone: formPhone,
      siteName: formSiteName,
      dailyRate: parseFloat(formDailyRate) || 150,
      activeDays: [],
      totalPaid: 0
    };

    setDailyLabor([...dailyLabor, payload]);
    setShowAddModal(false);
    setFormName('');
    setFormPhone('');
    setFormDailyRate('150');
  };

  // Settle Accounts (Clear active dates and move total to totalPaid archives)
  const handleSettlePayments = (workerId: string) => {
    const target = dailyLabor.find(w => w.id === workerId);
    if (!target) return;
    const pendingDues = target.activeDays.length * target.dailyRate;
    if (pendingDues === 0) {
      alert(lang === 'ar' ? "ليس للعامل مستحقات جارية للصرف حالياً." : "No outstanding wages due.");
      return;
    }

    if (confirm(lang === 'ar' ? `هل تؤكد تسوية وصرف مبلغ ${pendingDues} EGP للعامل ${target.name}؟` : `Approve wage payout of ${pendingDues} EGP for ${target.name}?`)) {
      setDailyLabor(dailyLabor.map(w => {
        if (w.id === workerId) {
          return {
            ...w,
            totalPaid: w.totalPaid + pendingDues,
            activeDays: [] // clear log days once cleared
          };
        }
        return w;
      }));
      setShowPayoutId(workerId); // trigger digital receipts window
    }
  };

  const payoutTarget = dailyLabor.find(w => w.id === showPayoutId);

  return (
    <div className="space-y-6" id="daily-labor-tab-container">
      {/* Search and filters bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Keyword Search */}
          <div className="relative w-full sm:w-60">
            <Search className="absolute right-3 top-2.5 text-slate-400" size={18} />
            <input
              type="text"
              placeholder={lang === 'ar' ? 'البحث عن عامل...' : 'Search laborers...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
            />
          </div>

          {/* Site Filter */}
          <select
            value={selectedSite}
            onChange={(e) => setSelectedSite(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none"
          >
            <option value="">{t.selectSite}</option>
            {INITIAL_SITES.map((site, index) => (
              <option key={index} value={site.name}>{site.name.split('-')[0]}</option>
            ))}
          </select>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold cursor-pointer w-full sm:w-auto justify-center"
        >
          <Plus size={16} />
          {lang === 'ar' ? 'قيد عامل يومية جديد' : 'Register Daily Hand'}
        </button>
      </div>

      {/* Main Table Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 dark:bg-slate-950/50 text-slate-400 font-bold uppercase py-3 border-b border-slate-100 dark:border-slate-850">
              <tr>
                <th className="p-4">{lang === 'ar' ? 'العامل كود/الاسم' : 'Labor ID & Name'}</th>
                <th className="p-4">{lang === 'ar' ? 'مشروع التشغيل الميداني' : 'Assigned Site'}</th>
                <th className="p-4 text-center">{lang === 'ar' ? 'أجر اليوم الشامل' : 'Daily Wage Rate'}</th>
                <th className="p-4 text-center">{lang === 'ar' ? 'أيام العمل الجارية' : 'Unpaid Active Days'}</th>
                <th className="p-4 text-center">{lang === 'ar' ? 'المستحقات غير المدفوعة' : 'Accrued unpaid dues'}</th>
                <th className="p-4 text-center">{lang === 'ar' ? 'إجمالي المبالغ المدفوعة سابقاً' : 'Total payments settled'}</th>
                <th className="p-4 text-center">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
              {filteredLabor.map(worker => {
                const pendingAccum = worker.activeDays.length * worker.dailyRate;
                return (
                  <tr key={worker.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/30 transition">
                    <td className="p-4">
                      <div className="font-bold text-slate-800 dark:text-white">{worker.name}</div>
                      <div className="text-xxs text-slate-400 font-mono mt-0.5">{worker.id} • {worker.phone}</div>
                    </td>
                    <td className="p-4 text-slate-600 dark:text-slate-300 font-semibold text-indigo-500 dark:text-indigo-400">
                      {worker.siteName.split('-')[0].trim()}
                    </td>
                    <td className="p-4 text-center font-bold text-slate-700 dark:text-slate-300">
                      {worker.dailyRate} EGP
                    </td>
                    <td className="p-4 text-center">
                      <span className="px-2.5 py-1 text-xxs font-bold bg-slate-100 dark:bg-slate-800 rounded-full text-slate-600 dark:text-slate-300">
                        {worker.activeDays.length} {lang === 'ar' ? 'أيام' : 'days'}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${
                        pendingAccum > 0 ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 ring-1 ring-amber-100 dark:ring-amber-900/10' : 'bg-slate-50 text-slate-400 dark:bg-slate-950'
                      }`}>
                        {pendingAccum} EGP
                      </span>
                    </td>
                    <td className="p-4 text-center text-emerald-500 dark:text-emerald-400 font-bold">
                      {worker.totalPaid} EGP
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        {/* Quick Day Checkbox */}
                        <div className="flex gap-1.5" id="date-selection-triggers">
                          <button
                            onClick={() => setSelectedLogWorker(selectedLogWorker === worker.id ? null : worker.id)}
                            className="p-1 px-2 border border-slate-200 dark:border-slate-700 hover:border-indigo-500 rounded text-[10px] font-bold text-slate-500 hover:text-indigo-500 flex items-center gap-1"
                          >
                            <Calendar size={12} />
                            {lang === 'ar' ? 'رزنامة الأيام' : 'Calendar logs'}
                          </button>

                          <button
                            onClick={() => handleSettlePayments(worker.id)}
                            disabled={pendingAccum === 0}
                            className={`p-1 px-2.5 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer transition ${
                              pendingAccum > 0 ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'bg-slate-100 text-slate-400 dark:bg-slate-950 dark:text-slate-800'
                            }`}
                          >
                            <Coins size={12} />
                            {lang === 'ar' ? 'تصفية وصرف' : 'Clear Wage'}
                          </button>
                        </div>
                      </div>

                      {/* Expanded check-off sub-row */}
                      {selectedLogWorker === worker.id && (
                        <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-950 text-right rounded-lg border border-slate-200 dark:border-slate-800 space-y-2 animate-fadeIn max-w-xs">
                          <p className="font-bold text-[10px] text-slate-400 mb-1">{lang === 'ar' ? 'انقر على تاريخ لتسجيل / إلغاء يوم العمل:' : 'Click dates to toggle check-in status:'}</p>
                          <div className="grid grid-cols-4 gap-1">
                            {["2026-05-28", "2026-05-29", "2026-05-30", "2026-05-31"].map(d => {
                              const active = worker.activeDays.includes(d);
                              return (
                                <button
                                  key={d}
                                  onClick={() => handleToggleDay(worker.id, d)}
                                  className={`p-1 text-[8px] font-bold rounded-lg ${
                                    active ? "bg-emerald-500 text-white" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-500"
                                  }`}
                                >
                                  {d.substring(5)}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Disbursed Digital Payslip Receipt */}
      {payoutTarget && (
        <div id="receipt-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-white text-slate-800 p-6 rounded-2xl border-4 border-slate-900 max-w-sm w-full relative">
            <button
              onClick={() => setShowPayoutId(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
            >
              <X size={20} />
            </button>

            {/* Printable Area slips */}
            <div id="daily-payslip-printable" className="p-4 border border-dashed border-slate-400 rounded-xl bg-slate-50 text-slate-800">
              <div className="text-center pb-3 border-b border-dashed border-slate-300">
                <h4 className="text-sm font-extrabold uppercase tracking-widest text-slate-900">Smart HRMS Daily Labor Cash Receipt</h4>
                <p className="text-[10px] text-slate-400 mt-1 font-mono">Serial Slip: REC-2026-{payoutTarget.id}</p>
                <p className="text-[9px] text-slate-500">{new Date().toLocaleString()}</p>
              </div>

              <div className="mt-4 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'ar' ? 'اسم العامل المستفيد' : 'Beneficiary name'}</span>
                  <span className="font-bold text-slate-900">{payoutTarget.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'ar' ? 'الكود التعريفي' : 'Labor ID'}</span>
                  <span className="font-bold text-slate-900 font-mono">{payoutTarget.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'ar' ? 'مستند موقع العمل' : 'Project site'}</span>
                  <span className="font-bold text-slate-700">{payoutTarget.siteName.split('-')[0]}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'ar' ? 'فئة الأجر اليومي المنصرم' : 'Disbursed wage rate'}</span>
                  <span className="font-bold text-slate-700">{payoutTarget.dailyRate} EGP / Shift</span>
                </div>
                
                <div className="flex justify-between border-t border-dashed border-slate-300 pt-3 text-sm font-semibold text-slate-900">
                  <span>{lang === 'ar' ? 'إجمالي المبلغ المسلم نقداً' : 'Total net cash paid'}</span>
                  <span className="text-emerald-500 font-bold text-base">{payoutTarget.totalPaid} EGP</span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-4 text-center text-[9px] text-slate-400 border-t border-dashed border-slate-300 pt-4">
                <div>
                  <p>{lang === 'ar' ? 'توقيع أمين الصندوق' : 'Treasurer stamp'}</p>
                  <div className="h-8 border border-slate-200 mt-1 rounded border-dashed flex items-center justify-center text-[8px] text-slate-300">Smart Cash Seal</div>
                </div>
                <div>
                  <p>{lang === 'ar' ? 'بصمة/توقيع المستلم' : 'Beneficiary sign'}</p>
                  <div className="h-8 border border-slate-200 mt-1 rounded border-dashed flex items-center justify-center text-[7px] text-slate-300">Authorized Pass</div>
                </div>
              </div>
            </div>

            {/* Print trigger button */}
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-850 text-white text-xs font-semibold py-2 px-4 rounded-xl cursor-pointer"
              >
                <Printer size={15} />
                {lang === 'ar' ? 'طباعة القسيمة النقدية' : 'Print cash slip'}
              </button>
              <button
                onClick={() => setShowPayoutId(null)}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-100 rounded-xl text-xs text-slate-500"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enroll Labor Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white rounded-2xl max-w-sm w-full p-6 relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X size={20} />
            </button>

            <h3 className="text-base font-bold mb-4">{lang === 'ar' ? 'قيد عامل يومية تشغيلي' : 'Enroll Daily wages worker'}</h3>

            <form onSubmit={handleAddWorker} className="space-y-4">
              <div>
                <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.fullName} *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="بلال محمود غريب"
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.phone} *</label>
                <input
                  type="text"
                  required
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  placeholder="01014521453"
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{t.dailyRate} (EGP) *</label>
                <input
                  type="number"
                  required
                  value={formDailyRate}
                  onChange={(e) => setFormDailyRate(e.target.value)}
                  placeholder="200"
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xxs text-slate-400 font-bold mb-1 uppercase">{lang === 'ar' ? 'مشروع توزيع الميدان' : 'Assigned field project'}</label>
                <select
                  value={formSiteName}
                  onChange={(e) => setFormSiteName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
                >
                  {INITIAL_SITES.map((site, index) => (
                    <option key={index} value={site.name}>{site.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 justify-end mt-6">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-500 rounded-xl text-xs"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
