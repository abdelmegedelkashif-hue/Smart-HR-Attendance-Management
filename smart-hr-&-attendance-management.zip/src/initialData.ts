/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Employee, DailyLaborWorker, GPSSite, AttendanceRecord } from './types';

export const DEPARTMENTS = [
  "إدارة المشروعات (PM)",
  "الموارد البشرية (HR)",
  "الحسابات والمالية (Finance)",
  "الهندسة والموقع (Engineering)",
  "الأمن والسلامة (HSE)",
  "التوريدات والمخازن (Logistics)"
];

export const CONTRACT_TYPES = [
  "Full-time",
  "Part-time",
  "Contract",
  "Daily"
];

export const CONTRACT_TYPES_AR = {
  "Full-time": "دوام كامل",
  "Part-time": "دوام جزئي",
  "Contract": "عقد مؤقت",
  "Daily": "يومي محدد"
};

export const INITIAL_SITES: GPSSite[] = [
  { id: "SITE-01", name: "المقر الرئيسي - جاردن سيتي، القاهرة", lat: 30.0401, lng: 31.2335, radiusM: 100 },
  { id: "SITE-02", name: "مشروع ميناء الإسكندرية الرصيف 55", lat: 31.2052, lng: 29.8972, radiusM: 250 },
  { id: "SITE-03", name: "موقع العاصمة الإدارية الجديدة - البرج الأيقوني", lat: 29.9821, lng: 31.7511, radiusM: 400 }
];

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: "EMP-101",
    name: "محمد علي جابر",
    nationalId: "29007150102345",
    position: "مدير المشروع الميداني",
    department: "إدارة المشروعات (PM)",
    projectSite: "المقر الرئيسي - جاردن سيتي، القاهرة",
    hireDate: "2021-03-12",
    salary: 22000,
    contractType: "Full-time",
    phone: "01012345678",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: [
      { id: "DOC-1", name: "صورة بطاقة الرقم القومي", type: "ID Proof", expiryDate: "2029-12-15" },
      { id: "DOC-2", name: "عقد التعيين الموثق", type: "Contract", expiryDate: "2028-03-12" }
    ]
  },
  {
    id: "EMP-102",
    name: "أحمد ممدوح حسن",
    nationalId: "29204050201345",
    position: "مهندس تنفيذ مدني ورئيس موقع",
    department: "الهندسة والموقع (Engineering)",
    projectSite: "مشروع ميناء الإسكندرية الرصيف 55",
    hireDate: "2023-01-10",
    salary: 15500,
    contractType: "Full-time",
    phone: "01234567890",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: [
      { id: "DOC-3", name: "كارنيه نقابة المهندسين", type: "Professional ID", expiryDate: "2027-12-31" }
    ]
  },
  {
    id: "EMP-103",
    name: "أميرة محمود يوسف",
    nationalId: "29511210103212",
    position: "أخصائية شؤون العاملين ورواتب",
    department: "الموارد البشرية (HR)",
    projectSite: "المقر الرئيسي - جاردن سيتي، القاهرة",
    hireDate: "2024-05-01",
    salary: 9500,
    contractType: "Full-time",
    phone: "01145612345",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: [
      { id: "DOC-4", name: "شهادة الفيش الجنائي حديثة", type: "Security clearance", expiryDate: "2026-11-20" }
    ]
  },
  {
    id: "EMP-104",
    name: "خالد سعيد المصري",
    nationalId: "28709120109988",
    position: "رئيس مشرفي السلامة والصحة المهنية",
    department: "الأمن والسلامة (HSE)",
    projectSite: "مشروع ميناء الإسكندرية الرصيف 55",
    hireDate: "2020-08-20",
    salary: 11000,
    contractType: "Contract",
    phone: "01511223344",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: [
      { id: "DOC-5", name: "دورة الاوشا HSE المعتمدة", type: "License", expiryDate: "2026-06-15" }
    ]
  },
  {
    id: "EMP-105",
    name: "ياسر رضوان كمال",
    nationalId: "29408220104523",
    position: "فني ومشرف ورشة تشغيل موقع",
    department: "الهندسة والموقع (Engineering)",
    projectSite: "موقع العاصمة الإدارية الجديدة - البرج الأيقوني",
    hireDate: "2022-11-05",
    salary: 8200,
    contractType: "Daily",
    phone: "01009876543",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: []
  },
  {
    id: "EMP-106",
    name: "فاطمة عبد الرحمن مصطفى",
    nationalId: "29610150102223",
    position: "محاسبة أولى للمقاولات والموردين",
    department: "الحسابات والمالية (Finance)",
    projectSite: "المقر الرئيسي - جاردن سيتي، القاهرة",
    hireDate: "2022-02-15",
    salary: 13000,
    contractType: "Full-time",
    phone: "01211224455",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: []
  },
  {
    id: "EMP-107",
    name: "نورهان حسن فاروق",
    nationalId: "29812300109981",
    position: "دعم فني ومتابعة توريدات ميدان",
    department: "التوريدات والمخازن (Logistics)",
    projectSite: "موقع العاصمة الإدارية الجديدة - البرج الأيقوني",
    hireDate: "2025-01-02",
    salary: 7500,
    contractType: "Full-time",
    phone: "01199887766",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=128&q=80",
    status: "active",
    documents: []
  }
];

export const INITIAL_DAILY_LABOR: DailyLaborWorker[] = [
  { id: "LAB-01", name: "مصطفى الصاوي شعبان", phone: "01021457812", siteName: "موقع العاصمة الإدارية الجديدة - البرج الأيقوني", dailyRate: 250, activeDays: ["2026-05-28", "2026-05-29", "2026-05-30", "2026-05-31"], totalPaid: 1000 },
  { id: "LAB-02", name: "علي عبد اللطيف رفاعي", phone: "01254714523", siteName: "مشروع ميناء الإسكندرية الرصيف 55", dailyRate: 300, activeDays: ["2026-05-29", "2026-05-30", "2026-05-31"], totalPaid: 900 },
  { id: "LAB-03", name: "كريم الهواري مغربي", phone: "01145124112", siteName: "موقع العاصمة الإدارية الجديدة - البرج الأيقوني", dailyRate: 220, activeDays: ["2026-05-27", "2026-05-28", "2026-05-30"], totalPaid: 660 },
  { id: "LAB-04", name: "بلال عسكر جودة", phone: "01511221199", siteName: "المقر الرئيسي - جاردن سيتي، القاهرة", dailyRate: 200, activeDays: ["2026-05-30", "2026-05-31"], totalPaid: 400 }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  // 2026-05-29
  { id: "ATT-1001", employeeId: "EMP-101", employeeName: "محمد علي جابر", date: "2026-05-29", checkIn: "08:00", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1002", employeeId: "EMP-102", employeeName: "أحمد ممدوح حسن", date: "2026-05-29", checkIn: "07:45", checkOut: "18:00", status: "overtime", hoursWorked: 10.25, overtimeHours: 2.25, delayMinutes: 0, earlyLeaveMinutes: 0, method: "manual" },
  { id: "ATT-1003", employeeId: "EMP-103", employeeName: "أميرة محمود يوسف", date: "2026-05-29", checkIn: "08:05", checkOut: "16:00", status: "present", hoursWorked: 7.9, overtimeHours: 0, delayMinutes: 5, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1004", employeeId: "EMP-104", employeeName: "خالد سعيد المصري", date: "2026-05-29", checkIn: "08:00", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1005", employeeId: "EMP-105", employeeName: "ياسر رضوان كمال", date: "2026-05-29", checkIn: "08:45", checkOut: "16:00", status: "late", hoursWorked: 7.25, overtimeHours: 0, delayMinutes: 45, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1006", employeeId: "EMP-106", employeeName: "فاطمة عبد الرحمن مصطفى", date: "2026-05-29", checkIn: "08:00", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  
  // 2026-05-30
  { id: "ATT-1007", employeeId: "EMP-101", employeeName: "محمد علي جابر", date: "2026-05-30", checkIn: "07:58", checkOut: "16:15", status: "present", hoursWorked: 8.28, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1008", employeeId: "EMP-102", employeeName: "أحمد ممدوح حسن", date: "2026-05-30", checkIn: "08:00", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1010", employeeId: "EMP-104", employeeName: "خالد سعيد المصري", date: "2026-05-30", checkIn: "07:50", checkOut: "17:30", status: "overtime", hoursWorked: 9.6, overtimeHours: 1.5, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1011", employeeId: "EMP-105", employeeName: "ياسر رضوان كمال", date: "2026-05-30", checkIn: "08:35", checkOut: "15:45", status: "late", hoursWorked: 7.16, overtimeHours: 0, delayMinutes: 35, earlyLeaveMinutes: 15, method: "fingerprint" },
  { id: "ATT-1012", employeeId: "EMP-106", employeeName: "فاطمة عبد الرحمن مصطفى", date: "2026-05-30", checkIn: "08:00", checkOut: "16:05", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1013", employeeId: "EMP-107", employeeName: "نورهان حسن فاروق", date: "2026-05-30", checkIn: "08:00", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },

  // 2026-05-31 (Today)
  { id: "ATT-1014", employeeId: "EMP-101", employeeName: "محمد علي جابر", date: "2026-05-31", checkIn: "07:55", checkOut: "16:02", status: "present", hoursWorked: 8.1, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "gps", gpsLocation: { lat: 30.0402, lng: 31.2336, siteName: "المقر الرئيسي - جاردن سيتي، القاهرة", distanceM: 15 } },
  { id: "ATT-1015", employeeId: "EMP-102", employeeName: "أحمد ممدوح حسن", date: "2026-05-31", checkIn: "08:01", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 1, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1016", employeeId: "EMP-104", employeeName: "خالد سعيد المصري", date: "2026-05-31", checkIn: "07:49", checkOut: "18:30", status: "overtime", hoursWorked: 10.6, overtimeHours: 2.5, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1017", employeeId: "EMP-106", employeeName: "فاطمة عبد الرحمن مصطفى", date: "2026-05-31", checkIn: "08:02", checkOut: "16:00", status: "present", hoursWorked: 8, overtimeHours: 0, delayMinutes: 2, earlyLeaveMinutes: 0, method: "fingerprint" },
  { id: "ATT-1018", employeeId: "EMP-107", employeeName: "نورهان حسن فاروق", date: "2026-05-31", checkIn: "07:58", checkOut: "16:05", status: "present", hoursWorked: 8.1, overtimeHours: 0, delayMinutes: 0, earlyLeaveMinutes: 0, method: "fingerprint" }
];

// Haversine formula to compute geodesic distance in meters between two GPS coordinates
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // In meters
}
