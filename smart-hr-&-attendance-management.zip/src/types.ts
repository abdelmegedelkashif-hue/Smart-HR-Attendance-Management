/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Employee {
  id: string; // Document ID / Employee ID (e.g., EMP-101)
  name: string;
  nationalId: string;
  position: string;
  department: string;
  projectSite: string;
  hireDate: string;
  salary: number;
  contractType: 'Full-time' | 'Part-time' | 'Contract' | 'Daily';
  phone: string;
  avatar: string; // Base64 or placeholder URL
  status: 'active' | 'suspended';
  documents: EmployeeDocument[];
}

export interface EmployeeDocument {
  id: string;
  name: string;
  type: string;
  expiryDate: string;
  fileUrl?: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  checkIn: string; // HH:mm
  checkOut: string; // HH:mm
  status: 'present' | 'absent' | 'late' | 'early_leave' | 'overtime';
  hoursWorked: number;
  overtimeHours: number;
  delayMinutes: number;
  earlyLeaveMinutes: number;
  method: 'fingerprint' | 'ocr' | 'gps' | 'manual';
  gpsLocation?: {
    lat: number;
    lng: number;
    siteName: string;
    distanceM: number;
  };
  selfieUrl?: string;
}

export interface DailyLaborWorker {
  id: string;
  name: string;
  phone: string;
  siteName: string;
  dailyRate: number;
  activeDays: string[]; // List of YYYY-MM-DD dates worked
  totalPaid: number;
}

export interface GPSSite {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radiusM: number; // geofence radius in meters
}

export interface SystemUser {
  id: string;
  name: string;
  role: 'admin' | 'hr' | 'manager' | 'supervisor' | 'readonly';
  email: string;
}
