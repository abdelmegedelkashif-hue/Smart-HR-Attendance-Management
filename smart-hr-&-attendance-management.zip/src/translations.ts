/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const translations = {
  ar: {
    appTitle: "النظام الذكي لإدارة الموارد البشرية والحضور",
    appSubTitle: "لوحة التحكم التنفيذية للشركات وكشوف الميدان الذكية",
    langToggle: "English",
    themeToggle: "تغيير المظهر",
    dashboard: "لوحة التحكم",
    employees: "شؤون العاملين",
    attendance: "الحضور والانصراف",
    dailyLabor: "العمالة اليومية",
    fingerprintImport: "استيراد ملف البصمة",
    paperOcr: "مسح الكشوف الورقية (AI)",
    gpsMobile: "التحقق الجغرافي (GPS)",
    reports: "التقارير والغرامات",
    aiInsights: "المستشار الذكي (AI)",
    
    // Stats
    totalEmployees: "إجمالي الموظفين",
    activeStaff: "الكادر النشط",
    todayPresence: "حضور اليوم",
    todayAbsence: "غياب اليوم",
    todayDelay: "متأخرون اليوم",
    activeDailyLabor: "العمالة اليومية النشطة",
    totalDailyDue: "مستحقات اليومية الكلية",
    overtimeHours: "ساعات العمل الإضافية",
    effectiveHours: "ساعات العمل الفعلية",
    presenceRate: "معدل الانضباط العام",

    // Common Actions
    save: "حفظ",
    edit: "تعديل",
    delete: "حذف",
    cancel: "إلغاء",
    add: "إضافة جديد",
    print: "طباعة التقرير",
    exportExcel: "تصدير Excel",
    search: "بحث بالاسم أو الرقم الوظيفي...",
    status: "الحالة",
    active: "نشط",
    suspended: "موقوف مؤقتاً",
    actions: "الإجراءات",

    // Employees Form/Fields
    empId: "الرقم الوظيفي",
    fullName: "الاسم بالكامل",
    nationalId: "الرقم القومي (14 رقم)",
    position: "الوظيفة",
    department: "القسم",
    projectSite: "الموقع / المشروع",
    hireDate: "تاريخ التعيين",
    salary: "الراتب الأساسي",
    phone: "رقم الهاتف",
    contractType: "نوع التعاقد",
    fullTime: "دوام كامل",
    partTime: "دوام جزئي",
    contract: "عقد مؤقت",
    daily: "يومي محدد",
    employeeCard: "بطاقة تعريف الموظف",
    
    // Daily Labor Table
    dailyRate: "الأجر اليومي",
    daysWorkedCount: "أيام الحضور المسجلة",
    totalDues: "إجمالي المستحقات",
    selectSite: "تصفية حسب الموقع",
    recordDay: "تسجيل يوم عمل للمحدد",
    paidStatus: "تصفية الحساب ودفع الأجر",

    // Biometrics Import
    importDragText: "اسحب ملف بصمة الحضور هنا أو اضغط للاختيار",
    importLimits: "يدعم ملفات XLS, XLSX, CSV الصادرة عن أجهزة ZKTeco أو الأجهزة الشبيهة",
    loadSample: "تحميل ملف محاكاة تجريبي للبصمة",
    matchedRecords: "سجلات متطابقة",
    unregisteredAlert: "أرقام بصمة غير مسجلة بقاعدة البيانات",
    commitSuccess: "تم دمج ومعالجة سجلات الحضور بنجاح وتحصيل الساعات الإضافية والتأخيرات!",
    
    // GPS Geofence CheckIn
    simulateMobile: "محاكي التحقق من الهاتف الجغرافي للموظفين الميدانيين",
    yourLocation: "الموقع الجغرافي الحالي المحاكي",
    siteGeofence: "محيط المشروع المطابق",
    distanceLabel: "المسافة عن أقرب نقطة مشروع",
    selfieRequired: "التقاط صورة شخصية للتدقيق والمطابقة",
    insideGeofence: "داخل النطاق الجغرافي المسموح به",
    outsideGeofence: "خارج النطاق الجغرافي! لا يمكن تسجيل الحضور",
    captureSelfie: "التقاط صورة سيلفي",
    checkInSuccess: "تم تسجيل حضورك بنجاح من الموقع وتوثيق الصورة والإحداثيات!",
    
    // AI Scanner (OCR)
    ocrConsole: "منصة مسح المستندات وكشوف الحضور الورقية بالذكاء الاصطناعي",
    ocrUploadPrompt: "ارفع كشف الحضور المكتوب بخط اليد أو المطبوع من المواقع لكي يقوم Gemini بفك شفرته وتفريغ الجدول تلقائياً",
    previewExtracted: "مراجعة البيانات المستخرجة من الذكاء الاصطناعي قبل التثبيت",
    reconcileTable: "جدول المطابقة والتصحيح اليدوي",

    // AI Advisor
    intelligentAdvisor: "المستشار والمدقق الذكي (Gemini)",
    aiPromptText: "تحليل أنماط غياب وتأخر القوى العاملة واقتراح حلول للمخالفات المتكررة",
    runAiAnalysis: "تشغيل التحليلات التنبؤية الفورية",
    outstandingStaff: "الموظفون الأكثر التزاماً وتفانياً هذا الشهر",
    anomaliesFound: "المخالفات والثغرات التشغيلية المكتشفة",
    aiRecommendations: "التوصيات الإدارية المقترحة من النظام",
    noDataYet: "لم يتم إنشاء تحليل بعد. اضغط على الزر لتشخيص البيانات الحالية باستخدام الذكاء الاصطناعي."
  },
  en: {
    appTitle: "Smart HR & Attendance Management System",
    appSubTitle: "Executive Enterprise Dashboard & Smart Field Log Hub",
    langToggle: "العربية",
    themeToggle: "Toggle Theme",
    dashboard: "Dashboard",
    employees: "Employee Profiles",
    attendance: "Attendance Log",
    dailyLabor: "Daily Wages Labor",
    fingerprintImport: "Biometric Logs Import",
    paperOcr: "Manual Sheet OCR Scanner",
    gpsMobile: "GPS Geofenced Portal",
    reports: "Advanced Reports",
    aiInsights: "Intelligent Advisor (AI)",

    // Stats
    totalEmployees: "Total Employees",
    activeStaff: "Active Personnel",
    todayPresence: "Today's Presence",
    todayAbsence: "Today's Absence",
    todayDelay: "Today's Late Arrivals",
    activeDailyLabor: "Active Daily Laborers",
    totalDailyDue: "Daily Labor Dues",
    overtimeHours: "Overtime Hours Worked",
    effectiveHours: "Total Effective Hours",
    presenceRate: "Overall Punctuality Rate",

    // Common Actions
    save: "Save",
    edit: "Edit",
    delete: "Delete",
    cancel: "Cancel",
    add: "Add Employee",
    print: "Print Report",
    exportExcel: "Export CSV",
    search: "Search by ID or name...",
    status: "Status",
    active: "Active",
    suspended: "Suspended",
    actions: "Actions",

    // Employees Form
    empId: "Employee ID",
    fullName: "Full Name",
    nationalId: "National ID (14 digits)",
    position: "Position",
    department: "Department",
    projectSite: "Project / Site Location",
    hireDate: "Date of Hire",
    salary: "Base Salary",
    phone: "Phone Number",
    contractType: "Contract Category",
    fullTime: "Full Time",
    partTime: "Part Time",
    contract: "Contractor",
    daily: "Daily-Wages",
    employeeCard: "Employee Corporate Badge",

    // Daily Labor Table
    dailyRate: "Daily Wage rate",
    daysWorkedCount: "Days Logged",
    totalDues: "Net Total Dues",
    selectSite: "Filter by Site Location",
    recordDay: "Check-in Day Log",
    paidStatus: "Clear Accounts & Settle Balances",

    // Biometrics Import
    importDragText: "Drag & drop biometric software logs here or click to browse",
    importLimits: "Supports XLS, XLSX, CSV logs exported from ZKTime or similar systems",
    loadSample: "Preload Simulation Biometric Records",
    matchedRecords: "Identified Employee Rows",
    unregisteredAlert: "Unregistered Badge Codes Detected",
    commitSuccess: "All biometric check-ins parsed, and overtime/delay deductions calculated!",

    // GPS Geofence CheckIn
    simulateMobile: "Field Geofenced Mobile Simulation Portal",
    yourLocation: "Simulated Live Coordinate GPS",
    siteGeofence: "Corresponding Project Geofenced Hub",
    distanceLabel: "Distance is",
    selfieRequired: "Upload selfie credential for live face validation",
    insideGeofence: "Approved: Inside Active Site Geofence Zone",
    outsideGeofence: "Rejected: You are outside the designated project boundaries!",
    captureSelfie: "Snap Verification Selfie",
    checkInSuccess: "Mobile GPS check-in accomplished successfully with verified selfie proof!",

    // AI Scanner (OCR)
    ocrConsole: "AI Optical Character Recognition (OCR) Workspace Container",
    ocrUploadPrompt: "Upload dynamic pictures of handwritten or printed log notes for Gemini Vision parsing",
    previewExtracted: "Review Extracted Spreadsheet Grid before saving to live register",
    reconcileTable: "Verification & Time Adjustment Editor",

    // AI Advisor
    intelligentAdvisor: "Gemini Intelligent Advisor Audit Suite",
    aiPromptText: "Deep machine analytics modeling for workers absenteeism, bottlenecks & warning drafts",
    runAiAnalysis: "Execute Predictive Intelligence Diagnosis",
    outstandingStaff: "Top Dedicated & Compliant Nominees This Month",
    anomaliesFound: "Diagnosed Shift Exceptions & Operating Anomaly Items",
    aiRecommendations: "Actionable Operational Recommendations from AI Assistant",
    noDataYet: "Critical analytical engine idling. Execute Predictive Intelligence logs audit above."
  }
};
