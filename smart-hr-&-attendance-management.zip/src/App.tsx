/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { translations } from './translations';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_ATTENDANCE, 
  INITIAL_DAILY_LABOR, 
  INITIAL_SITES 
} from './initialData';
import { Employee, AttendanceRecord, DailyLaborWorker } from './types';

// Firebase Specific Imports
import { signInWithPopup, GoogleAuthProvider, signOut, User } from 'firebase/auth';
import { collection, doc, getDocs, setDoc, deleteDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';

// Tab Views
import { DashboardTab } from './components/DashboardTab';
import { EmployeesTab } from './components/EmployeesTab';
import { DailyLaborTab } from './components/DailyLaborTab';
import { BiometricImportTab } from './components/BiometricImportTab';
import { PaperOcrTab } from './components/PaperOcrTab';
import { GpsMobileTab } from './components/GpsMobileTab';
import { ReportsTab } from './components/ReportsTab';
import { AiInsightsTab } from './components/AiInsightsTab';

// Icons
import { 
  Building2, 
  Globe, 
  Moon, 
  Sun, 
  LayoutDashboard, 
  Users, 
  Clock, 
  Hammer, 
  Barcode, 
  Camera, 
  Navigation, 
  FileText, 
  Sparkles,
  UserCheck,
  UserPlus
} from 'lucide-react';

export default function App() {
  // Localization state
  const [lang, setLang] = useState<'ar' | 'en'>(() => {
    const cached = localStorage.getItem('hrms_lang');
    return (cached === 'ar' || cached === 'en') ? cached : 'ar';
  });

  // Dark/Light Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const cached = localStorage.getItem('hrms_theme');
    return (cached === 'dark' || cached === 'light') ? cached : 'dark';
  });

  // Active workspace tab
  const [activeTab, setActiveTab] = useState<string>(() => {
    return localStorage.getItem('hrms_active_tab') || 'dashboard';
  });

  // Global Core Registers (from LocalStorage or pre-populated InitialData constants)
  const [employees, rawSetEmployees] = useState<Employee[]>(() => {
    const cached = localStorage.getItem('hrms_employees');
    return cached ? JSON.parse(cached) : INITIAL_EMPLOYEES;
  });

  const [attendance, rawSetAttendance] = useState<AttendanceRecord[]>(() => {
    const cached = localStorage.getItem('hrms_attendance');
    return cached ? JSON.parse(cached) : INITIAL_ATTENDANCE;
  });

  const [dailyLabor, rawSetDailyLabor] = useState<DailyLaborWorker[]>(() => {
    const cached = localStorage.getItem('hrms_daily_labor');
    return cached ? JSON.parse(cached) : INITIAL_DAILY_LABOR;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [triggerAddEmployee, setTriggerAddEmployee] = useState(0);

  // Firestore synchronised dispatchers (interceptors)
  const setEmployees: React.Dispatch<React.SetStateAction<Employee[]>> = (value) => {
    rawSetEmployees((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      if (auth.currentUser) {
        setIsSyncing(true);
        const prevMap = new Map(prev.map(e => [e.id, e]));
        const nextMap = new Map(next.map(e => [e.id, e]));

        // Handle Deletes
        for (const item of prev) {
          if (!nextMap.has(item.id)) {
            deleteDoc(doc(db, 'employees', item.id))
              .catch(err => handleFirestoreError(err, OperationType.DELETE, `employees/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }

        // Handle Edits and Additions
        for (const item of next) {
          const prevItem = prevMap.get(item.id);
          if (!prevItem || JSON.stringify(prevItem) !== JSON.stringify(item)) {
            setDoc(doc(db, 'employees', item.id), item)
              .catch(err => handleFirestoreError(err, OperationType.WRITE, `employees/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }
      }
      return next;
    });
  };

  const setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>> = (value) => {
    rawSetAttendance((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      if (auth.currentUser) {
        setIsSyncing(true);
        const prevMap = new Map(prev.map(a => [a.id, a]));
        const nextMap = new Map(next.map(a => [a.id, a]));

        // Handle Deletes
        for (const item of prev) {
          if (!nextMap.has(item.id)) {
            deleteDoc(doc(db, 'attendance', item.id))
              .catch(err => handleFirestoreError(err, OperationType.DELETE, `attendance/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }

        // Handle Edits and Additions
        for (const item of next) {
          const prevItem = prevMap.get(item.id);
          if (!prevItem || JSON.stringify(prevItem) !== JSON.stringify(item)) {
            setDoc(doc(db, 'attendance', item.id), item)
              .catch(err => handleFirestoreError(err, OperationType.WRITE, `attendance/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }
      }
      return next;
    });
  };

  const setDailyLabor: React.Dispatch<React.SetStateAction<DailyLaborWorker[]>> = (value) => {
    rawSetDailyLabor((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      if (auth.currentUser) {
        setIsSyncing(true);
        const prevMap = new Map(prev.map(l => [l.id, l]));
        const nextMap = new Map(next.map(l => [l.id, l]));

        // Handle Deletes
        for (const item of prev) {
          if (!nextMap.has(item.id)) {
            deleteDoc(doc(db, 'dailyLabor', item.id))
              .catch(err => handleFirestoreError(err, OperationType.DELETE, `dailyLabor/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }

        // Handle Edits and Additions
        for (const item of next) {
          const prevItem = prevMap.get(item.id);
          if (!prevItem || JSON.stringify(prevItem) !== JSON.stringify(item)) {
            setDoc(doc(db, 'dailyLabor', item.id), item)
              .catch(err => handleFirestoreError(err, OperationType.WRITE, `dailyLabor/${item.id}`))
              .finally(() => setIsSyncing(false));
          }
        }
      }
      return next;
    });
  };

  // Sync to local storage for local offline session
  useEffect(() => {
    localStorage.setItem('hrms_lang', lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('hrms_theme', theme);
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('hrms_active_tab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    localStorage.setItem('hrms_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('hrms_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('hrms_daily_labor', JSON.stringify(dailyLabor));
  }, [dailyLabor]);

  // Sync with Firestore on user Authentication
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      setCurrentUser(user);
      if (user) {
        setIsSyncing(true);
        try {
          // Sync Employees
          const empSnap = await getDocs(collection(db, 'employees'));
          let fbEmployees: Employee[] = [];
          if (empSnap.empty) {
            for (const emp of INITIAL_EMPLOYEES) {
              await setDoc(doc(db, 'employees', emp.id), emp);
            }
            fbEmployees = INITIAL_EMPLOYEES;
          } else {
            empSnap.forEach(d => {
              fbEmployees.push(d.data() as Employee);
            });
          }
          rawSetEmployees(fbEmployees);

          // Sync Attendance
          const attSnap = await getDocs(collection(db, 'attendance'));
          let fbAttendance: AttendanceRecord[] = [];
          if (attSnap.empty) {
            for (const att of INITIAL_ATTENDANCE) {
              await setDoc(doc(db, 'attendance', att.id), att);
            }
            fbAttendance = INITIAL_ATTENDANCE;
          } else {
            attSnap.forEach(d => {
              fbAttendance.push(d.data() as AttendanceRecord);
            });
          }
          rawSetAttendance(fbAttendance);

          // Sync Daily Labor
          const laborSnap = await getDocs(collection(db, 'dailyLabor'));
          let fbLabor: DailyLaborWorker[] = [];
          if (laborSnap.empty) {
            for (const lab of INITIAL_DAILY_LABOR) {
              await setDoc(doc(db, 'dailyLabor', lab.id), lab);
            }
            fbLabor = INITIAL_DAILY_LABOR;
          } else {
            laborSnap.forEach(d => {
              fbLabor.push(d.data() as DailyLaborWorker);
            });
          }
          rawSetDailyLabor(fbLabor);
        } catch (error) {
          console.error("Firebase initial syncing failed: ", error);
        } finally {
          setIsSyncing(false);
        }
      } else {
        // Safe fall back to local cached storage
        const cachedEmployees = localStorage.getItem('hrms_employees');
        const cachedAttendance = localStorage.getItem('hrms_attendance');
        const cachedDailyLabor = localStorage.getItem('hrms_daily_labor');
        
        rawSetEmployees(cachedEmployees ? JSON.parse(cachedEmployees) : INITIAL_EMPLOYEES);
        rawSetAttendance(cachedAttendance ? JSON.parse(cachedAttendance) : INITIAL_ATTENDANCE);
        rawSetDailyLabor(cachedDailyLabor ? JSON.parse(cachedDailyLabor) : INITIAL_DAILY_LABOR);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Sign-in failed:", err);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Sign-out failed:", err);
    }
  };

  const t = translations[lang];

  return (
    <div 
      className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition duration-200"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      id="root-viewport-container"
    >
      {/* Upper Navigation Rail */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-100 dark:border-slate-850 px-6 py-4 flex items-center justify-between shadow-xs">
        {/* Branding header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-tr from-indigo-600 to-indigo-800 text-white rounded-xl shadow-md">
            <Building2 size={24} />
          </div>
          <div>
            <h1 className="text-sm font-extrabold uppercase tracking-wide text-slate-850 dark:text-white flex items-center gap-1.5 leading-none">
              Smart HRMS
              <span className="text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold px-2 py-0.5 rounded-full uppercase">Enterprise</span>
            </h1>
            <p className="text-[10px] text-slate-400 mt-1 font-semibold">
              {t.appSubTitle}
            </p>
          </div>
        </div>

        {/* Global toggles header bar */}
        <div className="flex items-center gap-2">
          {/* Sync indicator */}
          {isSyncing && (
            <span className="text-[10px] text-indigo-500 font-bold animate-pulse px-2 py-1 bg-indigo-500/10 rounded-lg">
              {lang === 'ar' ? 'جاري المزامنة...' : 'Syncing...'}
            </span>
          )}

          {/* Cloud Sync State */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-850 rounded-xl border border-slate-200/50 dark:border-slate-800 text-xs">
                {currentUser.photoURL && (
                  <img src={currentUser.photoURL} alt={currentUser.displayName || ''} className="w-4 h-4 rounded-full" referrerPolicy="no-referrer" />
                )}
                <span className="font-bold text-slate-700 dark:text-slate-200 max-w-[120px] truncate">
                  {currentUser.displayName || currentUser.email}
                </span>
              </div>
              <button
                onClick={handleSignOut}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-rose-50 dark:bg-slate-850 dark:hover:bg-rose-950/20 text-xs font-bold text-rose-500 border border-slate-200 dark:border-slate-800 transition cursor-pointer select-none"
              >
                {lang === 'ar' ? 'تسجيل الخروج' : 'Sign Out'}
              </button>
            </div>
          ) : (
            <button
              onClick={handleGoogleSignIn}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-600 dark:bg-indigo-950/40 dark:hover:bg-indigo-950/80 dark:text-indigo-400 text-xs font-bold border border-indigo-200/50 dark:border-indigo-900/40 transition cursor-pointer shadow-sm select-none"
            >
              <UserCheck size={14} />
              <span>{lang === 'ar' ? 'مزامنة السحاب (Google)' : 'Cloud Sync (Google)'}</span>
            </button>
          )}

          {/* Create Employee Direct CTA */}
          <button
            onClick={() => {
              setActiveTab('employees');
              setTriggerAddEmployee(prev => prev + 1);
            }}
            id="btn-quick-add-employee"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white dark:bg-emerald-950/40 dark:hover:bg-emerald-950/80 dark:text-emerald-400 text-xs font-bold border border-transparent dark:border-emerald-900/40 shadow-sm hover:shadow active:scale-95 transition-all select-none cursor-pointer"
            title={lang === 'ar' ? 'إدخال بيانات موظف جديد' : 'Register New Employee Data'}
          >
            <UserPlus size={14} className="animate-pulse" />
            <span>
              {lang === 'ar' ? 'إدخال بيانات موظف' : 'Enter Employee Data'}
            </span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            id="btn-lang-toggle"
            title="Switch Language"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-950 text-xs font-bold text-slate-500 hover:text-indigo-500 cursor-pointer transition select-none"
          >
            <Globe size={14} className="animate-spin-slow" />
            <span>{t.langToggle}</span>
          </button>

          {/* Theme switcher */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            id="btn-theme-toggle"
            title="Toggle theme"
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-950 text-slate-500 hover:text-indigo-500 cursor-pointer transition"
          >
            {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
          </button>
        </div>
      </header>

      {/* Main Body container */}
      <div className="flex-1 w-full max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Interactive Sidebar Options */}
        <aside className="lg:col-span-1 space-y-2">
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 px-3 uppercase tracking-wider mb-2">
            {lang === 'ar' ? 'أقسام لوحة التحكم' : 'Navigation Hub'}
          </p>

          <nav className="flex flex-col gap-1" id="hr-navigation-menu">
            {/* Tab 1: Dashboard */}
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'dashboard' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <LayoutDashboard size={16} />
              <span>{t.dashboard}</span>
            </button>

            {/* Tab 2: Employees CRUD */}
            <button
              onClick={() => setActiveTab('employees')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'employees' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Users size={16} />
              <span>{t.employees}</span>
            </button>

            {/* Tab 3: Daily labor */}
            <button
              onClick={() => setActiveTab('dailyLabor')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'dailyLabor' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Hammer size={16} />
              <span>{t.dailyLabor}</span>
            </button>

            <span className="block border-t border-slate-100 dark:border-slate-850/30 my-2"></span>
            
            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 px-3 uppercase tracking-wider mb-2">
              {lang === 'ar' ? 'استيراد الحضور والـ GPS' : 'Attendance Interfaces'}
            </p>

            {/* Tab 4: Biometric spreadsheet parsing */}
            <button
              onClick={() => setActiveTab('fingerprintImport')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'fingerprintImport' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Barcode size={16} />
              <span>{t.fingerprintImport}</span>
            </button>

            {/* Tab 5: Paper OCR camera scan */}
            <button
              onClick={() => setActiveTab('paperOcr')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'paperOcr' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Camera size={16} />
              <span>{t.paperOcr}</span>
            </button>

            {/* Tab 6: GPS geofencing simulation portal */}
            <button
              onClick={() => setActiveTab('gpsMobile')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'gpsMobile' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Navigation size={16} />
              <span>{t.gpsMobile}</span>
            </button>

            <span className="block border-t border-slate-100 dark:border-slate-850/30 my-2"></span>

            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 px-3 uppercase tracking-wider mb-2">
              {lang === 'ar' ? 'التقارير والاستشارات' : 'Reporting & Analytics'}
            </p>

            {/* Tab 7: HR advanced reports */}
            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'reports' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <FileText size={16} />
              <span>{t.reports}</span>
            </button>

            {/* Tab 8: AI Advisor */}
            <button
              onClick={() => setActiveTab('aiInsights')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                activeTab === 'aiInsights' ? 
                'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' : 
                'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900 hover:text-indigo-500'
              }`}
            >
              <Sparkles size={16} className="text-violet-500 animate-pulse" />
              <span>{t.aiInsights}</span>
            </button>
          </nav>
        </aside>

        {/* Dynamic Display Panel (Right Side, occupies 4 cols) */}
        <main className="lg:col-span-4" id="main-content-canvas-container">
          <div className="animate-fadeIn">
            {activeTab === 'dashboard' && (
              <DashboardTab 
                lang={lang} 
                employees={employees} 
                attendance={attendance} 
                dailyLabor={dailyLabor} 
              />
            )}

            {activeTab === 'employees' && (
              <EmployeesTab 
                lang={lang} 
                employees={employees} 
                setEmployees={setEmployees} 
                triggerAddEmployee={triggerAddEmployee}
              />
            )}

            {activeTab === 'dailyLabor' && (
              <DailyLaborTab 
                lang={lang} 
                dailyLabor={dailyLabor} 
                setDailyLabor={setDailyLabor} 
              />
            )}

            {activeTab === 'fingerprintImport' && (
              <BiometricImportTab 
                lang={lang} 
                employees={employees} 
                attendance={attendance} 
                setAttendance={setAttendance} 
              />
            )}

            {activeTab === 'paperOcr' && (
              <PaperOcrTab 
                lang={lang} 
                employees={employees} 
                attendance={attendance} 
                setAttendance={setAttendance} 
              />
            )}

            {activeTab === 'gpsMobile' && (
              <GpsMobileTab 
                lang={lang} 
                employees={employees} 
                attendance={attendance} 
                setAttendance={setAttendance} 
              />
            )}

            {activeTab === 'reports' && (
              <ReportsTab 
                lang={lang} 
                attendance={attendance} 
                employees={employees} 
              />
            )}

            {activeTab === 'aiInsights' && (
              <AiInsightsTab 
                lang={lang} 
                employees={employees} 
                attendance={attendance} 
              />
            )}
          </div>
        </main>
      </div>

      {/* Modern Compact Footers */}
      <footer className="bg-white dark:bg-slate-900 py-4 px-6 text-center text-xxs border-t border-slate-100 dark:border-slate-850 text-slate-400 font-semibold print:hidden mt-auto">
        Smart HRMS Dashboard & Field Platform © {new Date().getFullYear()} • 
        {lang === 'ar' ? ' مجمع برمجيات الموارد البشرية والسيطرة الميدانية' : ' Integrated Human Resource Intelligence System'}
      </footer>
    </div>
  );
}
